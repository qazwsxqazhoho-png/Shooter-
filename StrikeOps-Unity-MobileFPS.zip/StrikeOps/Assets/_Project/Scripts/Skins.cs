using System.Collections.Generic;
using UnityEngine;

namespace StrikeOps
{
    public enum SkinPattern { Solid, Gradient, Camo, Carbon, Stripes }

    public sealed class SkinDef
    {
        public string Name;
        public SkinPattern Pattern;
        public Color A;
        public Color B;
        public int Seed;
    }

    public sealed class SkinDatabase
    {
        public readonly List<SkinDef> Skins = new List<SkinDef>
        {
            new SkinDef { Name = "Штатный", Pattern = SkinPattern.Solid, A = new Color(0.42f, 0.46f, 0.50f), B = new Color(0.5f, 0.5f, 0.5f), Seed = 1 },
            new SkinDef { Name = "Заря", Pattern = SkinPattern.Gradient, A = new Color(1.00f, 0.45f, 0.10f), B = new Color(0.85f, 0.10f, 0.55f), Seed = 2 },
            new SkinDef { Name = "Тайга", Pattern = SkinPattern.Camo, A = new Color(0.24f, 0.34f, 0.20f), B = new Color(0.55f, 0.60f, 0.35f), Seed = 3 },
            new SkinDef { Name = "Карбон", Pattern = SkinPattern.Carbon, A = new Color(0.08f, 0.08f, 0.09f), B = new Color(0.25f, 0.25f, 0.27f), Seed = 4 },
            new SkinDef { Name = "Полярный", Pattern = SkinPattern.Camo, A = new Color(0.88f, 0.91f, 0.94f), B = new Color(0.60f, 0.72f, 0.85f), Seed = 5 },
            new SkinDef { Name = "Магма", Pattern = SkinPattern.Gradient, A = new Color(0.06f, 0.05f, 0.05f), B = new Color(0.95f, 0.25f, 0.05f), Seed = 6 },
            new SkinDef { Name = "Ретро-80", Pattern = SkinPattern.Stripes, A = new Color(0.95f, 0.20f, 0.55f), B = new Color(0.10f, 0.85f, 0.85f), Seed = 7 },
            new SkinDef { Name = "Хром", Pattern = SkinPattern.Gradient, A = new Color(0.85f, 0.88f, 0.92f), B = new Color(0.45f, 0.50f, 0.58f), Seed = 8 },
            new SkinDef { Name = "Шторм", Pattern = SkinPattern.Camo, A = new Color(0.30f, 0.42f, 0.55f), B = new Color(0.65f, 0.70f, 0.75f), Seed = 9 },
            new SkinDef { Name = "Абиссаль", Pattern = SkinPattern.Gradient, A = new Color(0.02f, 0.10f, 0.25f), B = new Color(0.05f, 0.65f, 0.65f), Seed = 10 },
        };

        public SkinDef Default => Skins[0];

        public SkinDef ByName(string name)
        {
            foreach (var s in Skins)
                if (s.Name == name) return s;
            return Default;
        }

        readonly Dictionary<string, Material> matCache = new Dictionary<string, Material>();

        public Material GetMaterial(SkinDef skin, WeaponKind kind)
        {
            string key = skin.Name + "|" + kind;
            if (matCache.TryGetValue(key, out var m) && m != null) return m;
            m = MakeWeaponMaterial(skin, kind);
            matCache[key] = m;
            return m;
        }

        static Material MakeWeaponMaterial(SkinDef s, WeaponKind kind)
        {
            var m = new Material(Shader.Find("Standard"));
            m.mainTexture = TextureFactory.Get(s, kind);
            if (s.Pattern == SkinPattern.Carbon || s.Name == "Хром")
            {
                m.SetFloat("_Metallic", 0.75f);
                m.SetFloat("_Glossiness", 0.65f);
            }
            else
            {
                m.SetFloat("_Metallic", 0.25f);
                m.SetFloat("_Glossiness", 0.35f);
            }
            m.name = "skin_" + s.Name;
            return m;
        }
    }

    public static class TextureFactory
    {
        const int Size = 256;

        static readonly Dictionary<string, Texture2D> cache = new Dictionary<string, Texture2D>();

        public static Texture2D Get(SkinDef skin, WeaponKind kind)
        {
            string key = skin.Name + "|" + kind;
            if (cache.TryGetValue(key, out var t) && t != null) return t;
            var tex = Generate(skin, kind);
            cache[key] = tex;
            return tex;
        }

        struct Blob
        {
            public float Cx, Cy, Rx, Ry;
            public bool UseB;
        }

        static Texture2D Generate(SkinDef s, WeaponKind kind)
        {
            var rng = new System.Random(s.Seed * 131 + (int)kind * 17);

            Blob[] blobs = null;
            if (s.Pattern == SkinPattern.Camo)
            {
                blobs = new Blob[46];
                for (int i = 0; i < blobs.Length; i++)
                {
                    blobs[i] = new Blob
                    {
                        Cx = (float)rng.NextDouble() * Size,
                        Cy = (float)rng.NextDouble() * Size,
                        Rx = 14f + (float)rng.NextDouble() * 30f,
                        Ry = 10f + (float)rng.NextDouble() * 24f,
                        UseB = rng.NextDouble() < 0.5
                    };
                }
            }

            var tex = new Texture2D(Size, Size, TextureFormat.RGBA32, false)
            {
                filterMode = FilterMode.Bilinear,
                wrapMode = TextureWrapMode.Repeat
            };
            var px = new Color32[Size * Size];

            for (int y = 0; y < Size; y++)
            {
                for (int x = 0; x < Size; x++)
                {
                    Color c;
                    switch (s.Pattern)
                    {
                        case SkinPattern.Solid:
                            c = AddNoise(s.A, 0.05f, rng);
                            break;
                        case SkinPattern.Gradient:
                            c = Color.Lerp(s.A, s.B, y / (float)(Size - 1));
                            c = AddNoise(c, 0.04f, rng);
                            break;
                        case SkinPattern.Camo:
                            c = CamoPixel(s, blobs, x, y, rng);
                            break;
                        case SkinPattern.Carbon:
                            c = CarbonPixel(s, x, y);
                            break;
                        default:
                            c = StripePixel(s, x, y, rng);
                            break;
                    }
                    px[y * Size + x] = c;
                }
            }

            tex.SetPixels32(px);
            tex.Apply();
            return tex;
        }

        static Color CamoPixel(SkinDef s, Blob[] blobs, int x, int y, System.Random rng)
        {
            for (int i = 0; i < blobs.Length; i++)
            {
                var b = blobs[i];
                float dx = (x - b.Cx) / b.Rx;
                float dy = (y - b.Cy) / b.Ry;
                if (dx * dx + dy * dy <= 1f)
                    return AddNoise(b.UseB ? s.B : s.A * 0.72f, 0.05f, rng);
            }
            return AddNoise(s.A, 0.06f, rng);
        }

        static Color CarbonPixel(SkinDef s, int x, int y)
        {
            int shift = (y / 8) * 4;
            bool warp = ((x + shift) % 8) < 4;
            bool edge = (x + shift) % 8 == 0 || (y % 8) == 0;
            var c = warp ? s.B : s.A;
            if (edge) c *= 1.35f;
            return c;
        }

        static Color StripePixel(SkinDef s, int x, int y, System.Random rng)
        {
            bool stripe = ((x + y) / 22) % 2 == 0;
            var c = stripe ? s.A : s.B;
            return AddNoise(c, 0.05f, rng);
        }

        static Color AddNoise(Color c, float amount, System.Random rng)
        {
            float n = (float)(rng.NextDouble() * 2.0 - 1.0) * amount;
            return new Color(
                Mathf.Clamp01(c.r + n),
                Mathf.Clamp01(c.g + n),
                Mathf.Clamp01(c.b + n));
        }
    }

    public static class SkinPrefs
    {
        public static string Get(WeaponKind kind) => PlayerPrefs.GetString("skin_" + kind, string.Empty);

        public static void Set(WeaponKind kind, string name)
        {
            PlayerPrefs.SetString("skin_" + kind, name);
            PlayerPrefs.Save();
        }
    }
}
