using System.Collections;
using UnityEngine;

namespace StrikeOps
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class BotBrain : MonoBehaviour
    {
        public bool Controlled = true;

        CharacterController cc;
        BotHealth health;
        FxSystem fx;
        MatchState match;
        AudioSource src;
        WeaponDef def;
        MapInfo map;
        Transform eye, visual;
        string botName;
        int botId;
        System.Random rng;

        enum State { Patrol, Engage, Hunt }
        State state = State.Patrol;

        Vector3 moveTarget;
        float idleT, scanT, lastSeenT, reactionT, nextShot, burstCd, strafeT, avoidT;
        int burst, wpIndex, avoidSide;
        float strafeDir = 1f, aimErr;
        float velY;
        IDamageable target;

        public void Init(string name, int id, MapInfo mapInfo, MatchState m, FxSystem fxSystem,
            AudioSource audioSrc, BotHealth botHealth, Transform eyeT, Transform visualT)
        {
            botName = name;
            botId = id;
            map = mapInfo;
            match = m;
            fx = fxSystem;
            src = audioSrc;
            health = botHealth;
            eye = eyeT;
            visual = visualT;
            def = GameConfig.MakeBotRifle();
            rng = new System.Random(id * 977 + 13);
            PickWaypoint();
        }

        public void OnDied(HitInfo hit)
        {
            Controlled = false;
            target = null;
            cc.enabled = false;
            StartCoroutine(CorpseAndRespawn());
        }

        IEnumerator CorpseAndRespawn()
        {
            Quaternion from = transform.rotation;
            Quaternion to = Quaternion.Euler(0f, from.eulerAngles.y, 90f);
            float t = 0f;
            while (t < 0.4f)
            {
                t += Time.deltaTime;
                transform.rotation = Quaternion.Lerp(from, to, t / 0.4f);
                yield return null;
            }
            yield return new WaitForSeconds(Mathf.Max(0.1f, GameConfig.RespawnDelay - 0.4f));

            transform.position = map.Spawns[Random.Range(0, map.Spawns.Count)];
            transform.rotation = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);
            health.Revive();
            cc.enabled = true;
            state = State.Patrol;
            PickWaypoint();
            Controlled = true;
        }

        void Awake() => cc = GetComponent<CharacterController>();

        void Update()
        {
            if (!Controlled || Time.timeScale <= 0f || !health.IsAlive)
            {
                Move(Vector3.zero);
                return;
            }

            scanT -= Time.deltaTime;
            if (scanT <= 0f)
            {
                scanT = 0.2f;
                Scan();
            }

            switch (state)
            {
                case State.Patrol: DoPatrol(); break;
                case State.Engage: DoEngage(); break;
                case State.Hunt: DoHunt(); break;
            }
        }

        void Scan()
        {
            IDamageable best = null;
            float bestDist = float.MaxValue;
            Vector3 eyePos = eye.position;

            foreach (var c in CombatantRegistry.All)
            {
                if (c.Id == botId || !c.IsAlive) continue;

                Vector3 to = c.AimPoint - eyePos;
                float dist = to.magnitude;
                if (dist > 34f) continue;

                Vector3 flatTo = new Vector3(to.x, 0f, to.z);
                if (flatTo.sqrMagnitude > 0.01f)
                {
                    float angle = Vector3.Angle(new Vector3(transform.forward.x, 0f, transform.forward.z), flatTo);
                    if (angle > 80f && dist > 6f) continue;
                }

                if (Physics.Raycast(eyePos, to / dist, out RaycastHit hit, dist, ~0, QueryTriggerInteraction.Ignore))
                {
                    var v = CombatUtil.FindVictim(hit.collider);
                    if (v == null || v.Id != c.Id) continue;
                }

                if (dist < bestDist)
                {
                    bestDist = dist;
                    best = c;
                }
            }

            if (best != null)
            {
                if (target == null || target.Id != best.Id)
                    reactionT = 0.35f + (float)rng.NextDouble() * 0.3f;
                target = best;
                lastSeenT = 0f;
                state = State.Engage;
            }
            else if (state == State.Engage)
            {
                lastSeenT += 0.2f;
                if (lastSeenT > 1.2f)
                {
                    moveTarget = target != null ? target.AimPoint : transform.position;
                    target = null;
                    state = State.Hunt;
                }
            }
        }

        void DoEngage()
        {
            if (target == null || !target.IsAlive)
            {
                target = null;
                state = State.Patrol;
                PickWaypoint();
                Move(Vector3.zero);
                return;
            }

            Vector3 tp = target.AimPoint;
            Vector3 to = tp - transform.position;
            to.y = 0f;
            float dist = to.magnitude;
            if (dist > 0.1f) Face(to);

            reactionT -= Time.deltaTime;
            aimErr = Mathf.Min(aimErr + Time.deltaTime * 1.5f, 2.4f);

            strafeT -= Time.deltaTime;
            if (strafeT <= 0f)
            {
                strafeT = Random.Range(0.7f, 1.6f);
                strafeDir = Random.value < 0.5f ? -1f : 1f;
            }

            Vector3 strafe = Vector3.Cross(Vector3.up, to.normalized) * strafeDir;
            Vector3 advance = dist > 16f ? to.normalized : (dist < 7f ? -to.normalized : Vector3.zero);
            Move((strafe * 0.7f + advance) * 3.6f);

            if (reactionT > 0f) return;

            if (burst <= 0)
            {
                burstCd -= Time.deltaTime;
                if (burstCd <= 0f) burst = Random.Range(3, 7);
            }
            else if (Time.time >= nextShot)
            {
                nextShot = Time.time + 60f / def.Rpm;
                burst--;
                if (burst == 0) burstCd = Random.Range(0.6f, 1.2f);
                FireShot(tp);
            }
        }

        void FireShot(Vector3 targetPoint)
        {
            Vector3 dir = (targetPoint - eye.position).normalized;
            float dist = Vector3.Distance(eye.position, targetPoint);
            float errDeg = Mathf.Max(0.8f, 3.4f - aimErr) * (1f + dist * 0.02f);

            dir = Quaternion.Euler(
                (float)(rng.NextDouble() * 2.0 - 1.0) * errDeg,
                (float)(rng.NextDouble() * 2.0 - 1.0) * errDeg,
                0f) * dir;

            Ballistics.FireRay(eye.position, dir, def, botId, botName, fx);
            SoundFactory.Play(src, Sfx.Shot, 0.8f);
        }

        void DoPatrol()
        {
            idleT -= Time.deltaTime;
            if (idleT > 0f)
            {
                Move(Vector3.zero);
                return;
            }

            Vector3 to = moveTarget - transform.position;
            to.y = 0f;
            if (to.magnitude < 1.2f)
            {
                idleT = Random.Range(0.4f, 1.4f);
                PickWaypoint();
                Move(Vector3.zero);
                return;
            }

            Face(to);

            if (avoidT > 0f)
            {
                avoidT -= Time.deltaTime;
                to = Quaternion.Euler(0f, 70f * avoidSide, 0f) * to;
            }
            else if (Physics.Raycast(transform.position + Vector3.up * 0.9f, to.normalized, 1.4f, ~0, QueryTriggerInteraction.Ignore))
            {
                avoidSide = Random.value < 0.5f ? -1 : 1;
                avoidT = 0.6f;
            }

            Move(to.normalized * 2.8f);
        }

        void DoHunt()
        {
            Vector3 to = moveTarget - transform.position;
            to.y = 0f;
            if (to.magnitude < 1.5f)
            {
                idleT += Time.deltaTime;
                Move(Vector3.zero);
                if (idleT > 1.5f)
                {
                    idleT = 0f;
                    state = State.Patrol;
                    PickWaypoint();
                }
                return;
            }
            Face(to);
            Move(to.normalized * 3.4f);
        }

        void PickWaypoint()
        {
            int next = Random.Range(0, map.Waypoints.Count);
            if (next == wpIndex) next = (next + 1) % map.Waypoints.Count;
            wpIndex = next;
            moveTarget = map.Waypoints[wpIndex];
        }

        void Face(Vector3 to)
        {
            float targetYaw = Mathf.Atan2(to.x, to.z) * Mathf.Rad2Deg;
            float yaw = Mathf.MoveTowardsAngle(transform.eulerAngles.y, targetYaw, 320f * Time.deltaTime);
            transform.rotation = Quaternion.Euler(0f, yaw, 0f);
        }

        void Move(Vector3 horizontal)
        {
            velY -= GameConfig.Gravity * Time.deltaTime;
            if (cc.isGrounded && velY < 0f) velY = -2f;
            cc.Move((horizontal + Vector3.up * velY) * Time.deltaTime);
        }
    }
}
