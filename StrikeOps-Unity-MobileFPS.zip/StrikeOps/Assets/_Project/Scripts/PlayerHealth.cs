using System;
using System.Collections;
using UnityEngine;

namespace StrikeOps
{
    public sealed class PlayerHealth : MonoBehaviour, IDamageable
    {
        public int Id => MatchState.PlayerId;
        public string DisplayName => "Вы";
        public bool IsAlive => hp > 0f;
        public Vector3 AimPoint => transform.position + Vector3.up * 1.4f;
        public float Hp => hp;
        public float Armor => armor;
        public bool Dead { get; private set; }
        public float RespawnTimer { get; private set; }

        public event Action<HitInfo> Died;
        public event Action Damaged;

        float hp = 100f;
        float armor = 50f;

        MatchState match;
        MapInfo map;
        PlayerMotor motor;
        WeaponSystem weapons;

        public void Init(MatchState m, MapInfo mapInfo, PlayerMotor playerMotor, WeaponSystem weaponSystem)
        {
            match = m;
            map = mapInfo;
            motor = playerMotor;
            weapons = weaponSystem;
            CombatantRegistry.Register(this);
        }

        void OnDestroy() => CombatantRegistry.Unregister(this);

        public void ReceiveHit(HitInfo hit)
        {
            if (!IsAlive || !match.Running) return;

            if (armor > 0f)
            {
                float absorb = Mathf.Min(armor, hit.Damage * 0.5f);
                armor -= absorb;
                hit.Damage -= absorb;
            }

            hp -= hit.Damage;
            Damaged?.Invoke();

            if (hp <= 0f)
            {
                hp = 0f;
                Die(hit);
            }
        }

        void Die(HitInfo hit)
        {
            match.RegisterKill(hit.AttackerId, hit.AttackerName, this, hit.WeaponName, hit.Zone == HitZone.Head);
            Died?.Invoke(hit);

            Dead = true;
            RespawnTimer = GameConfig.RespawnDelay;
            motor.Enabled = false;
            weapons.SetDead(true);
            StartCoroutine(Respawn());
        }

        IEnumerator Respawn()
        {
            while (RespawnTimer > 0f)
            {
                RespawnTimer -= Time.deltaTime;
                yield return null;
            }

            transform.position = PickSpawn();
            motor.ResetVertical();
            hp = 100f;
            armor = 50f;
            Dead = false;
            motor.Enabled = true;
            weapons.SetDead(false);
            weapons.RefillAll();
        }

        Vector3 PickSpawn()
        {
            Vector3 best = map.Spawns[0];
            float bestScore = -1f;
            foreach (var s in map.Spawns)
            {
                float minDist = float.MaxValue;
                foreach (var c in CombatantRegistry.All)
                {
                    if (c.Id == Id || !c.IsAlive) continue;
                    minDist = Mathf.Min(minDist, Vector3.Distance(s, c.AimPoint));
                }
                if (minDist > bestScore)
                {
                    bestScore = minDist;
                    best = s;
                }
            }
            return best;
        }
    }
}
