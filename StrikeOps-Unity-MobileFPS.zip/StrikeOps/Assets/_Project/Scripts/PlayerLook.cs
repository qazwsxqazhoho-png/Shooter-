using UnityEngine;

namespace StrikeOps
{
    public sealed class PlayerLook : MonoBehaviour
    {
        public Camera Cam { get; private set; }
        public bool Zoomed { get; private set; }
        public Vector2 LastLookDelta { get; private set; }

        Transform pitchPivot;
        TouchInput touch;

        public float Yaw { get; private set; }
        public float Pitch { get; private set; }

        float recoilPitch, recoilYaw;
        float baseFov = 75f;
        float targetFov;

        public void Init(Camera cam, Transform pivot, TouchInput touchInput)
        {
            Cam = cam;
            pitchPivot = pivot;
            touch = touchInput;
            targetFov = baseFov;
        }

        public void SetZoom(bool on, float zoomFov)
        {
            Zoomed = on;
            targetFov = on ? zoomFov : baseFov;
        }

        public void AddRecoil(float pitchDeg, float yawDeg)
        {
            recoilPitch += pitchDeg;
            recoilYaw += yawDeg;
        }

        void Update()
        {
            if (Time.timeScale <= 0f)
            {
                if (touch != null) touch.ConsumeLook();
                return;
            }

            Vector2 look = touch != null ? touch.ConsumeLook() : Vector2.zero;
            LastLookDelta = look;

            bool blocked = touch != null && touch.UiBlocked;
            if (!blocked && Time.timeScale > 0f && Cursor.lockState != CursorLockMode.Locked && Input.GetMouseButtonDown(0))
                Cursor.lockState = CursorLockMode.Locked;
            if (Input.GetKeyDown(KeyCode.Escape))
                Cursor.lockState = CursorLockMode.None;

            float sens = GameConfig.SensScale * (Zoomed ? GameConfig.ZoomSensFactor : 1f);

            Yaw += look.x * GameConfig.TouchSensitivity * sens;
            Pitch -= look.y * GameConfig.TouchSensitivity * sens;

            if (Cursor.lockState == CursorLockMode.Locked)
            {
                Yaw += Input.GetAxis("Mouse X") * GameConfig.MouseSensitivity * sens;
                Pitch -= Input.GetAxis("Mouse Y") * GameConfig.MouseSensitivity * sens;
            }

            recoilPitch = Mathf.MoveTowards(recoilPitch, 0f, 14f * Time.deltaTime);
            recoilYaw = Mathf.MoveTowards(recoilYaw, 0f, 10f * Time.deltaTime);

            Pitch = Mathf.Clamp(Pitch + recoilPitch, -85f, 85f) - recoilPitch;
            Pitch = Mathf.Clamp(Pitch, -85f, 85f);

            transform.rotation = Quaternion.Euler(0f, Yaw + recoilYaw, 0f);
            pitchPivot.localRotation = Quaternion.Euler(Pitch + recoilPitch, 0f, 0f);

            if (!Mathf.Approximately(Cam.fieldOfView, targetFov))
                Cam.fieldOfView = Mathf.MoveTowards(Cam.fieldOfView, targetFov, 220f * Time.deltaTime);
        }
    }
}
