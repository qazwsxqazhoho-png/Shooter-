using UnityEngine;

namespace StrikeOps
{
    public sealed class PlayerRig
    {
        public GameObject Go;
        public PlayerMotor Motor;
        public PlayerLook Look;
        public PlayerHealth Health;
        public WeaponSystem Weapons;
        public WeaponView View;
    }

    public static class PlayerFactory
    {
        public static PlayerRig Create(MapInfo map, MatchState match, TouchInput touch, HudView hud, FxSystem fx, SkinDatabase skins)
        {
            var go = new GameObject("Player");
            var cc = go.AddComponent<CharacterController>();
            cc.height = 1.8f;
            cc.radius = 0.35f;
            cc.center = new Vector3(0f, 0.9f, 0f);
            cc.stepOffset = 0.4f;
            cc.slopeLimit = 45f;
            go.transform.position = map.Spawns[0];

            var pitchPivot = new GameObject("HeadPivot").transform;
            pitchPivot.SetParent(go.transform, false);
            pitchPivot.localPosition = new Vector3(0f, 1.62f, 0f);

            var camGo = new GameObject("Camera", typeof(Camera), typeof(AudioListener));
            camGo.transform.SetParent(pitchPivot, false);
            var cam = camGo.GetComponent<Camera>();
            cam.fieldOfView = 75f;
            cam.nearClipPlane = 0.05f;
            cam.farClipPlane = 200f;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.75f, 0.80f, 0.86f);
            camGo.tag = "MainCamera";

            var motor = go.AddComponent<PlayerMotor>();
            var look = go.AddComponent<PlayerLook>();
            var health = go.AddComponent<PlayerHealth>();
            var weapons = go.AddComponent<WeaponSystem>();

            var view = WeaponView.Create(cam, look, motor);

            look.Init(cam, pitchPivot, touch);
            motor.Init(touch, look);
            health.Init(match, map, motor, weapons);

            weapons.Init(cam, view, touch, look, fx, skins, motor, hud);

            health.Damaged += () => hud.DamageFlash();

            touch.SetSlotCount(5);
            weapons.StateChanged += () => touch.SetSlotActive(weapons.Index);

            return new PlayerRig
            {
                Go = go,
                Motor = motor,
                Look = look,
                Health = health,
                Weapons = weapons,
                View = view
            };
        }
    }
}
