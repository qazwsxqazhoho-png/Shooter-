using UnityEngine;

namespace StrikeOps
{
    public static class Ballistics
    {
        public static bool FireRay(Vector3 origin, Vector3 dir, WeaponDef def, int attackerId, string attackerName, FxSystem fx)
        {
            bool hitWall = Physics.Raycast(origin, dir, out RaycastHit hit, def.Range, ~0, QueryTriggerInteraction.Ignore);
            Vector3 end = hitWall ? hit.point : origin + dir * def.Range;

            if (fx != null && !def.Melee)
                fx.SpawnTracer(origin + dir * 0.5f, end);

            if (!hitWall) return false;

            IDamageable victim = CombatUtil.FindVictim(hit.collider);
            if (fx != null)
                fx.SpawnImpact(hit.point, hit.normal, victim != null);

            if (victim == null || !victim.IsAlive) return false;

            float dmg = DamageAt(def, hit.distance);
            HitZone zone = CombatUtil.ZoneFromPoint(hit.collider, hit.point);
            if (zone == HitZone.Head) dmg *= def.HeadMul;

            victim.ReceiveHit(new HitInfo
            {
                Damage = dmg,
                Zone = zone,
                AttackerId = attackerId,
                AttackerName = attackerName,
                WeaponName = def.ShortName,
                Point = hit.point,
                Normal = hit.normal
            });
            return true;
        }

        public static float DamageAt(WeaponDef def, float dist)
        {
            if (dist <= def.FalloffStart) return def.Damage;
            float t = Mathf.InverseLerp(def.FalloffStart, def.FalloffEnd, dist);
            return Mathf.Lerp(def.Damage, def.Damage * def.MinDamageFactor, t);
        }
    }
}
