using System;
using System.Collections;
using UnityEngine;

namespace StrikeOps
{
    public sealed class WeaponSystem : MonoBehaviour
    {
        public WeaponDef Current => slots[index].Def;
        public int Index => index;
        public int Mag => slots[index].Mag;
        public int Reserve => slots[index].Reserve;
        public bool IsReloading => reloading;
        public float CurrentSpreadDeg { get; private set; }

        public event Action StateChanged;

        struct Slot
        {
            public WeaponDef Def;
            public int Mag;
            public int Reserve;
        }

        Camera cam;
        WeaponView view;
        TouchInput touch;
        PlayerLook look;
        PlayerMotor motor;
        FxSystem fx;
        SkinDatabase skins;
        HudView hud;
        AudioSource src;
        System.Random rng = new System.Random();

        Slot[] slots;
        int index;
        float nextFireTime;
        float bloom;
        bool reloading, switching, dead, semiHeld;
        Coroutine reloadCo;

        public void Init(Camera camera, WeaponView weaponView, TouchInput touchInput, PlayerLook playerLook,
            FxSystem fxSystem, SkinDatabase skinDatabase, PlayerMotor playerMotor, HudView hudView)
        {
            cam = camera;
            view = weaponView;
            touch = touchInput;
            look = playerLook;
            fx = fxSystem;
            skins = skinDatabase;
            motor = playerMotor;
            hud = hudView;

            var defs = GameConfig.Loadout();
            slots = new Slot[defs.Length];
            for (int i = 0; i < defs.Length; i++)
                slots[i] = new Slot { Def = defs[i], Mag = defs[i].MagSize, Reserve = defs[i].Reserve };

            src = gameObject.AddComponent<AudioSource>();
            src.spatialBlend = 0f;
            src.volume = 0.8f;
            src.playOnAwake = false;

            SelectInstant(0);
        }

        void SelectInstant(int slot)
        {
            index = slot;
            view.BuildModel(slots[index].Def, MaterialFor(slots[index].Def.Kind));
            StateChanged?.Invoke();
        }

        Material MaterialFor(WeaponKind kind)
        {
            string saved = SkinPrefs.Get(kind);
            var skin = string.IsNullOrEmpty(saved) ? skins.Default : skins.ByName(saved);
            return skins.GetMaterial(skin, kind);
        }

        public void ApplySkin(SkinDef skin)
        {
            SkinPrefs.Set(Current.Kind, skin.Name);
            view.BuildModel(Current, MaterialFor(Current.Kind));
            SoundFactory.Play(src, Sfx.Switch);
        }

        public void SetDead(bool value)
        {
            dead = value;
            if (!dead) return;
            StopReload();
            if (look.Zoomed)
            {
                look.SetZoom(false, 0f);
                view.SetZoomVisible(false);
            }
        }

        public void RefillAll()
        {
            for (int i = 0; i < slots.Length; i++)
            {
                slots[i].Mag = slots[i].Def.MagSize;
                slots[i].Reserve = slots[i].Def.Reserve;
            }
            StateChanged?.Invoke();
        }

        void Update()
        {
            if (Time.timeScale <= 0f) return;
            if (dead) return;

            HandleSwitch();
            HandleReloadInput();
            HandleZoom();
            HandleFire();

            bloom = Mathf.MoveTowards(bloom, 0f, 5f * Time.deltaTime);
            if (!reloading && !switching)
                ComputeSpread(Current);
        }

        void HandleSwitch()
        {
            int want = touch != null ? touch.ConsumeSlot() : -1;
            if (want < 0)
            {
                for (int i = 0; i < slots.Length; i++)
                {
                    if (Input.GetKeyDown(KeyCode.Alpha1 + i))
                    {
                        want = i;
                        break;
                    }
                }
            }
            if (want >= 0 && want != index && !switching)
                StartCoroutine(SwitchTo(want));
        }

        IEnumerator SwitchTo(int target)
        {
            switching = true;
            StopReload();
            if (look.Zoomed)
            {
                look.SetZoom(false, 0f);
                view.SetZoomVisible(false);
            }

            view.Lower();
            SoundFactory.Play(src, Sfx.Switch);
            yield return new WaitForSeconds(0.22f);

            index = target;
            view.BuildModel(slots[index].Def, MaterialFor(slots[index].Def.Kind));
            StateChanged?.Invoke();
            view.Raise();

            yield return new WaitForSeconds(0.18f);
            switching = false;
        }

        void HandleReloadInput()
        {
            bool pressed = (touch != null && touch.ConsumeReload()) || Input.GetKeyDown(KeyCode.R);
            if (pressed) StartReload();
        }

        public void StartReload()
        {
            var s = slots[index];
            if (reloading || switching || dead || s.Def.Melee) return;
            if (s.Mag >= s.Def.MagSize || s.Reserve <= 0) return;

            if (look.Zoomed)
            {
                look.SetZoom(false, 0f);
                view.SetZoomVisible(false);
            }

            reloading = true;
            SoundFactory.Play(src, Sfx.Reload);
            view.PlayReload(s.Def.ReloadTime);
            reloadCo = StartCoroutine(FinishReload(s.Def.ReloadTime));
        }

        IEnumerator FinishReload(float t)
        {
            yield return new WaitForSeconds(t);
            reloading = false;
            reloadCo = null;

            var s = slots[index];
            int need = s.Def.MagSize - s.Mag;
            int take = Mathf.Min(need, s.Reserve);
            slots[index].Mag = s.Mag + take;
            slots[index].Reserve = s.Reserve - take;
            StateChanged?.Invoke();
        }

        void StopReload()
        {
            if (reloadCo != null)
            {
                StopCoroutine(reloadCo);
                reloadCo = null;
            }
            reloading = false;
        }

        void HandleZoom()
        {
            bool pressed = (touch != null && touch.ConsumeAimToggle())
                || (Cursor.lockState == CursorLockMode.Locked && Input.GetMouseButtonDown(1));

            if (pressed && Current.ZoomFov > 0f && !reloading && !switching)
            {
                bool on = !look.Zoomed;
                look.SetZoom(on, Current.ZoomFov);
                view.SetZoomVisible(on);
            }
        }

        void HandleFire()
        {
            if (reloading || switching) return;

            bool held = (touch != null && touch.FireHeld)
                || (Cursor.lockState == CursorLockMode.Locked && Input.GetMouseButton(0));

            var def = Current;

            if (def.Melee)
            {
                if (held && Time.time >= nextFireTime)
                {
                    nextFireTime = Time.time + 60f / def.Rpm;
                    MeleeSwing(def);
                }
                return;
            }

            bool trigger = def.Auto ? held : (held && !semiHeld);
            if (trigger && Time.time >= nextFireTime)
            {
                if (slots[index].Mag > 0)
                {
                    Fire(def);
                    semiHeld = true;
                }
                else if (Time.time >= nextFireTime)
                {
                    SoundFactory.Play(src, Sfx.Empty);
                    nextFireTime = Time.time + 0.4f;
                    StartReload();
                }
            }
            if (!held) semiHeld = false;
        }

        void Fire(WeaponDef def)
        {
            slots[index].Mag--;
            nextFireTime = Time.time + 60f / def.Rpm;

            float spread = ComputeSpread(def);
            Vector3 dir = cam.transform.forward;
            if (spread > 0.001f)
            {
                float rx = (float)(rng.NextDouble() * 2.0 - 1.0) * spread;
                float ry = (float)(rng.NextDouble() * 2.0 - 1.0) * spread;
                dir = (cam.transform.rotation * Quaternion.Euler(rx, ry, 0f)) * Vector3.forward;
            }

            Vector3 origin = cam.transform.position + dir * 0.25f;
            bool hitFlesh = Ballistics.FireRay(origin, dir, def, MatchState.PlayerId, "Вы", fx);

            look.AddRecoil(def.RecoilV, (float)(rng.NextDouble() * 2.0 - 1.0) * def.RecoilH);
            view.Kick();
            view.MuzzleFlash();

            var sfx = def.Kind == WeaponKind.Sniper ? Sfx.SniperShot
                    : def.Kind == WeaponKind.Smg ? Sfx.SmgShot
                    : Sfx.Shot;
            SoundFactory.Play(src, sfx);

            if (hitFlesh && hud != null)
                hud.OnPlayerHitConfirmed();

            StateChanged?.Invoke();
        }

        void MeleeSwing(WeaponDef def)
        {
            view.Kick();
            SoundFactory.Play(src, Sfx.Switch);
            Ballistics.FireRay(cam.transform.position, cam.transform.forward, def, MatchState.PlayerId, "Вы", null);
        }

        float ComputeSpread(WeaponDef def)
        {
            float baseSpread = look.Zoomed && def.ZoomFov > 0f ? def.SpreadZoom : def.SpreadHip;

            float moveFactor = 1f;
            if (motor != null)
            {
                float v = new Vector2(motor.Velocity.x, motor.Velocity.z).magnitude;
                moveFactor = 1f + Mathf.Clamp01(v / GameConfig.MoveSpeed) * 1.2f;
            }
            float air = motor != null && !motor.Grounded ? 2f : 1f;

            CurrentSpreadDeg = baseSpread * moveFactor * air + bloom;
            return CurrentSpreadDeg;
        }
    }
}
