using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace StrikeOps
{
    public sealed class KillFeedEntry
    {
        public int KillerId;
        public string Killer;
        public string Weapon;
        public string Victim;
        public bool Head;
    }

    public sealed class MatchState
    {
        public sealed class Standing
        {
            public int Id;
            public string Name;
            public int Score;
            public bool IsPlayer;
        }

        public const int PlayerId = 0;

        public int TargetScore { get; }
        public float MatchSeconds { get; }
        public float TimeLeft { get; private set; }
        public bool Running { get; private set; }

        readonly Dictionary<int, int> scores = new Dictionary<int, int>();

        public event Action<KillFeedEntry> KillFed;
        public event Action<List<Standing>> Ended;

        public MatchState(int target, float seconds)
        {
            TargetScore = target;
            MatchSeconds = seconds;
            TimeLeft = seconds;
        }

        public void Begin() => Running = true;

        public int GetScore(int id) => scores.TryGetValue(id, out var s) ? s : 0;

        public void Tick(float dt)
        {
            if (!Running) return;
            TimeLeft -= dt;
            if (TimeLeft <= 0f)
            {
                TimeLeft = 0f;
                Finish();
            }
        }

        public void RegisterKill(int killerId, string killerName, IDamageable victim, string weapon, bool head)
        {
            if (!Running) return;
            if (killerId != victim.Id)
                scores[killerId] = GetScore(killerId) + 1;

            KillFed?.Invoke(new KillFeedEntry
            {
                KillerId = killerId,
                Killer = killerName,
                Weapon = weapon,
                Victim = victim.DisplayName,
                Head = head
            });

            if (GetScore(killerId) >= TargetScore) Finish();
        }

        void Finish()
        {
            Running = false;
            Time.timeScale = 0f;
            Ended?.Invoke(Standings());
        }

        public List<Standing> Standings()
        {
            var list = new List<Standing>();
            foreach (var c in CombatantRegistry.All)
            {
                list.Add(new Standing
                {
                    Id = c.Id,
                    Name = c.DisplayName,
                    Score = GetScore(c.Id),
                    IsPlayer = c.Id == PlayerId
                });
            }
            return list.OrderByDescending(s => s.Score).ToList();
        }

        public void Restart()
        {
            Time.timeScale = 1f;
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}
