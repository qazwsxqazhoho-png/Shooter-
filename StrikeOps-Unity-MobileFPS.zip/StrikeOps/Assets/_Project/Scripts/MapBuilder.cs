using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace StrikeOps
{
    public sealed class MapInfo
    {
        public Transform Root;
        public readonly List<Vector3> Spawns = new List<Vector3>();
        public readonly List<Vector3> Waypoints = new List<Vector3>();
    }

    public static class MapBuilder
    {
        static Material groundMat, wallMat, crateMat, metalMat, accentMat, buildingMat;

        public static MapInfo Build(Transform parent)
        {
            var info = new MapInfo { Root = new GameObject("Map").transform };
            info.Root.SetParent(parent, false);
            SetupLighting();

            groundMat = Mat(new Color(0.72f, 0.66f, 0.50f), 0f);
            wallMat = Mat(new Color(0.58f, 0.57f, 0.54f), 0.05f);
            crateMat = Mat(new Color(0.52f, 0.40f, 0.26f), 0f);
            metalMat = Mat(new Color(0.50f, 0.52f, 0.56f), 0.35f);
            accentMat = Mat(new Color(0.80f, 0.42f, 0.14f), 0.05f);
            buildingMat = Mat(new Color(0.55f, 0.60f, 0.52f), 0f);

            // ЗАМЕНА ГРАФИКИ: здесь строится уровень из примитивов.
            // Можно заменить Box() на спавн своих моделей (Kenney / Asset Store), сохранив позиции и размеры.
            Box(info.Root, new Vector3(0f, -0.25f, 0f), new Vector3(60f, 0.5f, 60f), groundMat);
            Perimeter(info.Root);
            Building(info.Root, new Vector3(-14f, 0f, -10f), 0f);
            Building(info.Root, new Vector3(14f, 0f, 10f), 90f);
            Platform(info.Root);
            Crates(info.Root);
            Barriers(info.Root);

            info.Spawns.AddRange(new[]
            {
                new Vector3(26f, 0f, 26f), new Vector3(-26f, 0f, 26f),
                new Vector3(26f, 0f, -26f), new Vector3(-26f, 0f, -26f),
                new Vector3(0f, 0f, 26f), new Vector3(0f, 0f, -26f),
                new Vector3(26f, 0f, 0f), new Vector3(-26f, 0f, 0f)
            });

            info.Waypoints.AddRange(new[]
            {
                new Vector3(-24f, 0f, -24f), new Vector3(0f, 0f, -24f), new Vector3(24f, 0f, -24f),
                new Vector3(-24f, 0f, 0f), new Vector3(24f, 0f, 0f),
                new Vector3(-24f, 0f, 24f), new Vector3(0f, 0f, 24f), new Vector3(24f, 0f, 24f),
                new Vector3(0f, 0f, -12f), new Vector3(0f, 0f, 12f),
                new Vector3(-12f, 0f, 0f), new Vector3(12f, 0f, 0f),
                new Vector3(-14f, 0f, -2f), new Vector3(14f, 0f, 2f),
                new Vector3(-6f, 0f, 8f), new Vector3(6f, 0f, -8f)
            });

            return info;
        }

        static void SetupLighting()
        {
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.60f, 0.62f, 0.68f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = new Color(0.75f, 0.80f, 0.86f);
            RenderSettings.fogStartDistance = 45f;
            RenderSettings.fogEndDistance = 130f;
            QualitySettings.shadowDistance = 40f;
            QualitySettings.shadowCascades = 1;

            var sunGo = new GameObject("Sun");
            sunGo.transform.SetParent(new GameObject("LightingRoot").transform, false);
            sunGo.transform.SetParent(sunGo.transform.parent.parent, true);
            var light = sunGo.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.05f;
            light.shadows = LightShadows.Soft;
            sunGo.transform.rotation = Quaternion.Euler(52f, -38f, 0f);
        }

        static void Perimeter(Transform root)
        {
            Box(root, new Vector3(0f, 2f, -30.5f), new Vector3(62f, 4f, 1f), wallMat);
            Box(root, new Vector3(0f, 2f, 30.5f), new Vector3(62f, 4f, 1f), wallMat);
            Box(root, new Vector3(-30.5f, 2f, 0f), new Vector3(1f, 4f, 62f), wallMat);
            Box(root, new Vector3(30.5f, 2f, 0f), new Vector3(1f, 4f, 62f), wallMat);
        }

        static void Building(Transform root, Vector3 center, float yaw)
        {
            var b = new GameObject("Building").transform;
            b.SetParent(root, false);
            b.position = center;
            b.rotation = Quaternion.Euler(0f, yaw, 0f);

            WallWithDoor(b, new Vector3(0f, 1.75f, 4f), new Vector3(10f, 3.5f, 1f));
            WallWithDoor(b, new Vector3(0f, 1.75f, -4f), new Vector3(10f, 3.5f, 1f));
            Box(b, new Vector3(-4.8f, 1.75f, 0f), new Vector3(0.4f, 3.5f, 8f), buildingMat);
            Box(b, new Vector3(4.8f, 1.75f, 0f), new Vector3(0.4f, 3.5f, 8f), buildingMat);
            Box(b, new Vector3(0f, 3.7f, 0f), new Vector3(10.8f, 0.4f, 8.8f), metalMat);
        }

        static void WallWithDoor(Transform b, Vector3 centerPos, Vector3 fullSize)
        {
            float gap = 2.6f;
            float side = (fullSize.x - gap) * 0.5f;
            Box(b, centerPos + new Vector3(-(gap * 0.5f + side * 0.5f), 0f, 0f), new Vector3(side, fullSize.y, fullSize.z), buildingMat);
            Box(b, centerPos + new Vector3(gap * 0.5f + side * 0.5f, 0f, 0f), new Vector3(side, fullSize.y, fullSize.z), buildingMat);
            Box(b, centerPos + new Vector3(0f, fullSize.y * 0.5f - 0.55f, 0f), new Vector3(gap, 1.1f, fullSize.z), buildingMat);
        }

        static void Platform(Transform root)
        {
            Box(root, new Vector3(0f, 0.3f, 0f), new Vector3(7f, 0.6f, 7f), metalMat);
            Box(root, new Vector3(0f, 0.2f, 4.3f), new Vector3(2.4f, 0.4f, 1.0f), metalMat);
            Box(root, new Vector3(0f, 0.1f, 5.3f), new Vector3(2.4f, 0.2f, 1.0f), metalMat);
            Box(root, new Vector3(0f, 0.2f, -4.3f), new Vector3(2.4f, 0.4f, 1.0f), metalMat);
            Box(root, new Vector3(0f, 0.1f, -5.3f), new Vector3(2.4f, 0.2f, 1.0f), metalMat);
        }

        static void Crates(Transform root)
        {
            Cluster(root, new Vector3(-6f, 0f, 4f), 3);
            Cluster(root, new Vector3(8f, 0f, -6f), 2);
            Cluster(root, new Vector3(-20f, 0f, 14f), 2);
            Cluster(root, new Vector3(20f, 0f, -16f), 3);
            Cluster(root, new Vector3(-8f, 0f, -20f), 2);
            Cluster(root, new Vector3(10f, 0f, 20f), 2);
        }

        static void Cluster(Transform root, Vector3 at, int count)
        {
            Box(root, at + new Vector3(0f, 0.6f, 0f), new Vector3(1.2f, 1.2f, 1.2f), crateMat);
            if (count >= 2) Box(root, at + new Vector3(1.25f, 0.6f, 0f), new Vector3(1.2f, 1.2f, 1.2f), crateMat);
            if (count >= 3) Box(root, at + new Vector3(0.6f, 1.8f, 0f), new Vector3(1.2f, 1.2f, 1.2f), crateMat);
        }

        static void Barriers(Transform root)
        {
            Box(root, new Vector3(0f, 0.55f, -16f), new Vector3(5f, 1.1f, 0.5f), accentMat);
            Box(root, new Vector3(-16f, 0.55f, 6f), new Vector3(0.5f, 1.1f, 5f), accentMat);
            Box(root, new Vector3(16f, 0.55f, -6f), new Vector3(0.5f, 1.1f, 5f), accentMat);
            Box(root, new Vector3(6f, 0.55f, 16f), new Vector3(5f, 1.1f, 0.5f), accentMat);
        }

        static void Box(Transform parent, Vector3 pos, Vector3 size, Material mat)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = "block";
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localScale = size;
            go.GetComponent<MeshRenderer>().sharedMaterial = mat;
        }

        static Material Mat(Color c, float smooth)
        {
            var m = new Material(Shader.Find("Standard"));
            m.color = c;
            m.SetFloat("_Metallic", 0f);
            m.SetFloat("_Glossiness", smooth);
            return m;
        }
    }
}
