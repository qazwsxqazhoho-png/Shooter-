using UnityEngine;

namespace StrikeOps
{
    public static class BotFactory
    {
        static readonly string[] Names = { "Ворон", "Барс", "Кобра", "Призрак", "Шторм", "Гроза", "Лис" };
        static readonly Color[] Colors =
        {
            new Color(0.75f, 0.25f, 0.22f), new Color(0.20f, 0.55f, 0.55f),
            new Color(0.55f, 0.35f, 0.70f), new Color(0.80f, 0.55f, 0.15f),
            new Color(0.30f, 0.45f, 0.80f), new Color(0.45f, 0.65f, 0.25f),
            new Color(0.70f, 0.45f, 0.35f)
        };

        // ЗАМЕНА ГРАФИКИ: тело бота собрано из примитивов (капсула + голова + оружие).
        // Здесь можно подставить готовую модель персонажа вместо примитивов.
        public static void CreateAll(MapInfo map, MatchState match, FxSystem fx, int count, Transform parent)
        {
            for (int i = 0; i < count; i++)
            {
                int id = i + 1;
                string name = Names[i % Names.Length];

                var go = new GameObject("Bot_" + name + "_" + id);
                go.transform.SetParent(parent, false);
                go.transform.position = map.Spawns[(i + 1) % map.Spawns.Count];

                var cc = go.AddComponent<CharacterController>();
                cc.height = 1.8f;
                cc.radius = 0.35f;
                cc.center = new Vector3(0f, 0.9f, 0f);
                cc.slopeLimit = 45f;
                cc.stepOffset = 0.4f;

                var visual = new GameObject("Visual").transform;
                visual.SetParent(go.transform, false);

                var body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
                DestroyCollider(body);
                body.name = "Body";
                body.transform.SetParent(visual, false);
                body.transform.localPosition = new Vector3(0f, 0.75f, 0f);
                body.transform.localScale = new Vector3(0.6f, 0.75f, 0.6f);
                body.GetComponent<MeshRenderer>().sharedMaterial = FlatMat(Colors[i % Colors.Length]);

                var head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                DestroyCollider(head);
                head.name = "Head";
                head.transform.SetParent(visual, false);
                head.transform.localPosition = new Vector3(0f, 1.66f, 0f);
                head.transform.localScale = new Vector3(0.34f, 0.34f, 0.34f);
                head.GetComponent<MeshRenderer>().sharedMaterial = FlatMat(new Color(0.85f, 0.70f, 0.58f));

                var gun = GameObject.CreatePrimitive(PrimitiveType.Cube);
                DestroyCollider(gun);
                gun.name = "Gun";
                gun.transform.SetParent(visual, false);
                gun.transform.localPosition = new Vector3(0.28f, 1.25f, 0.35f);
                gun.transform.localScale = new Vector3(0.07f, 0.10f, 0.55f);
                gun.GetComponent<MeshRenderer>().sharedMaterial = FlatMat(new Color(0.18f, 0.18f, 0.20f));

                var eye = new GameObject("Eye").transform;
                eye.SetParent(go.transform, false);
                eye.localPosition = new Vector3(0f, 1.62f, 0f);

                var src = go.AddComponent<AudioSource>();
                src.spatialBlend = 1f;
                src.minDistance = 3f;
                src.maxDistance = 45f;
                src.rolloffMode = AudioRolloffMode.Linear;
                src.playOnAwake = false;

                var health = go.AddComponent<BotHealth>();
                var brain = go.AddComponent<BotBrain>();

                health.Init(id, name, match);
                brain.Init(name, id, map, match, fx, src, health, eye, visual);
                health.Died += brain.OnDied;
            }
        }

        static void DestroyCollider(GameObject go) => Object.Destroy(go.GetComponent<Collider>());

        static Material FlatMat(Color c)
        {
            var m = new Material(Shader.Find("Standard"));
            m.color = c;
            m.SetFloat("_Metallic", 0f);
            m.SetFloat("_Glossiness", 0.1f);
            return m;
        }
    }
}
