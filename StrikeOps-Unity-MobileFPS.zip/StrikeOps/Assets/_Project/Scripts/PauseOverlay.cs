using UnityEngine;
using UnityEngine.UI;

namespace StrikeOps
{
    public sealed class PauseOverlay : MonoBehaviour
    {
        GameObject mainPanel, skinsPanel;
        Text sensLabel, skinsTitle;
        TouchInput touch;
        SkinDatabase skins;
        MatchState match;
        WeaponSystem weapons;
        bool open;

        public static PauseOverlay Build(Transform canvasRoot)
        {
            var go = new GameObject("Pause", typeof(RectTransform));
            go.transform.SetParent(canvasRoot, false);
            UiUtil.Stretch((RectTransform)go.transform);
            var p = go.AddComponent<PauseOverlay>();

            var btn = UiUtil.MakeButton(go.transform, "PauseBtn", UiUtil.PauseIcon(), new Color(1f, 1f, 1f, 0.85f), p.Toggle);
            UiUtil.AnchorPoint(btn.GetComponent<RectTransform>(), new Vector2(0f, 1f), new Vector2(80f, -60f), new Vector2(72f, 72f));

            p.BuildMainPanel();
            p.BuildSkinsPanel();
            return p;
        }

        public void Init(TouchInput t, SkinDatabase db, MatchState m)
        {
            touch = t;
            skins = db;
            match = m;
        }

        public void SetWeapons(WeaponSystem w) => weapons = w;

        void BuildMainPanel()
        {
            mainPanel = new GameObject("MainPanel", typeof(RectTransform));
            mainPanel.transform.SetParent(transform, false);
            UiUtil.Stretch((RectTransform)mainPanel.transform);

            var dim = UiUtil.MakeImage(mainPanel.transform, "dim", UiUtil.White(), new Color(0f, 0f, 0f, 0.6f), raycast: true);
            UiUtil.Stretch(dim.rectTransform);

            var title = UiUtil.MakeText(mainPanel.transform, "title", "ПАУЗА", 44, Color.white, TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(title.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 240f), new Vector2(500f, 60f));

            MakeMenuButton(mainPanel.transform, "Продолжить", new Vector2(0f, 140f), Close);
            MakeMenuButton(mainPanel.transform, "Скины оружия", new Vector2(0f, 40f), OpenSkins);
            MakeMenuButton(mainPanel.transform, "Перезапуск матча", new Vector2(0f, -60f), () => match.Restart());
            MakeMenuButton(mainPanel.transform, "Выход из игры", new Vector2(0f, -160f), Application.Quit);

            var sensText = UiUtil.MakeText(mainPanel.transform, "sensText", "Чувствительность", 24, new Color(1f, 1f, 1f, 0.9f), TextAnchor.MiddleRight);
            UiUtil.AnchorPoint(sensText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(-90f, -255f), new Vector2(320f, 34f));

            var minus = UiUtil.MakeButton(mainPanel.transform, "sensMinus", UiUtil.White(), new Color(0.25f, 0.3f, 0.4f, 0.95f), () => ChangeSens(-0.1f));
            UiUtil.AnchorPoint(minus.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f), new Vector2(110f, -255f), new Vector2(70f, 56f));
            var minusLabel = UiUtil.MakeText(minus.transform, "l", "-", 30, Color.white, TextAnchor.MiddleCenter);
            UiUtil.Stretch(minusLabel.rectTransform);

            sensLabel = UiUtil.MakeText(mainPanel.transform, "sensVal", "1.0", 26, Color.white, TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(sensLabel.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(190f, -255f), new Vector2(90f, 34f));

            var plus = UiUtil.MakeButton(mainPanel.transform, "sensPlus", UiUtil.White(), new Color(0.25f, 0.3f, 0.4f, 0.95f), () => ChangeSens(0.1f));
            UiUtil.AnchorPoint(plus.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f), new Vector2(270f, -255f), new Vector2(70f, 56f));
            var plusLabel = UiUtil.MakeText(plus.transform, "l", "+", 30, Color.white, TextAnchor.MiddleCenter);
            UiUtil.Stretch(plusLabel.rectTransform);

            mainPanel.SetActive(false);
        }

        void MakeMenuButton(Transform parent, string label, Vector2 pos, System.Action onClick)
        {
            var btn = UiUtil.MakeButton(parent, "btn_" + label, UiUtil.White(), new Color(0.16f, 0.2f, 0.28f, 0.96f), onClick);
            UiUtil.AnchorPoint(btn.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f), pos, new Vector2(420f, 78f));
            var t = UiUtil.MakeText(btn.transform, "l", label, 28, Color.white, TextAnchor.MiddleCenter);
            UiUtil.Stretch(t.rectTransform);
        }

        void BuildSkinsPanel()
        {
            skinsPanel = new GameObject("SkinsPanel", typeof(RectTransform));
            skinsPanel.transform.SetParent(transform, false);
            UiUtil.Stretch((RectTransform)skinsPanel.transform);

            var dim = UiUtil.MakeImage(skinsPanel.transform, "dim", UiUtil.White(), new Color(0f, 0f, 0f, 0.6f), raycast: true);
            UiUtil.Stretch(dim.rectTransform);

            skinsTitle = UiUtil.MakeText(skinsPanel.transform, "title", "Скины", 40, Color.white, TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(skinsTitle.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 270f), new Vector2(700f, 50f));

            var back = UiUtil.MakeButton(skinsPanel.transform, "back", UiUtil.White(), new Color(0.16f, 0.2f, 0.28f, 0.96f), CloseSkins);
            UiUtil.AnchorPoint(back.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f), new Vector2(0f, -300f), new Vector2(300f, 70f));
            var backLabel = UiUtil.MakeText(back.transform, "l", "Назад", 26, Color.white, TextAnchor.MiddleCenter);
            UiUtil.Stretch(backLabel.rectTransform);

            skinsPanel.SetActive(false);
        }

        void OpenSkins()
        {
            mainPanel.SetActive(false);
            skinsPanel.SetActive(true);
            RefreshSkins();
        }

        void CloseSkins()
        {
            skinsPanel.SetActive(false);
            mainPanel.SetActive(true);
        }

        void RefreshSkins()
        {
            if (weapons == null || skins == null) return;

            var kind = weapons.Current.Kind;
            skinsTitle.text = "Скины — " + weapons.Current.ShortName;

            foreach (Transform child in skinsPanel.transform)
                if (child.name.StartsWith("skin"))
                    Destroy(child.gameObject);

            string current = SkinPrefs.Get(kind);
            for (int i = 0; i < skins.Skins.Count; i++)
            {
                var skin = skins.Skins[i];
                bool active = skin.Name == current;
                var btn = UiUtil.MakeButton(skinsPanel.transform, "skin" + i, UiUtil.White(),
                    active ? new Color(0.95f, 0.6f, 0.1f, 0.95f) : new Color(0.16f, 0.2f, 0.28f, 0.96f),
                    () => { weapons.ApplySkin(skin); RefreshSkins(); });

                int col = i % 2, row = i / 2;
                UiUtil.AnchorPoint(btn.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f),
                    new Vector2(col == 0 ? -180f : 180f, 180f - row * 95f), new Vector2(330f, 76f));

                var t = UiUtil.MakeText(btn.transform, "l", skin.Name, 26, Color.white, TextAnchor.MiddleCenter);
                UiUtil.Stretch(t.rectTransform);
            }
        }

        void ChangeSens(float delta)
        {
            GameConfig.SensScale = GameConfig.SensScale + delta;
            sensLabel.text = GameConfig.SensScale.ToString("0.0");
        }

        public void Toggle()
        {
            if (match != null && !match.Running) return;

            open = !open;
            skinsPanel.SetActive(false);
            mainPanel.SetActive(open);
            Time.timeScale = open ? 0f : 1f;

            if (touch != null)
            {
                touch.UiBlocked = open;
                if (open) touch.ForceRelease();
            }

            if (open && Cursor.lockState == CursorLockMode.Locked)
                Cursor.lockState = CursorLockMode.None;

            if (!open && sensLabel != null)
                sensLabel.text = GameConfig.SensScale.ToString("0.0");
        }

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape) && !open && match != null && match.Running)
                Toggle();
        }
    }
}
