using UnityEngine;
using UnityEngine.Rendering;

namespace StrikeOps
{
    public sealed class WeaponView : MonoBehaviour
    {
        Transform modelRoot;
        GameObject model;
        Material mat;
        PlayerLook look;
        PlayerMotor motor;

        Vector3 restPos;
        float kick;
        float bobT;
        float swayX;
        float reloadT, reloadDur;
        float lowerT, lowerTarget;
        float flashT;
        Transform flash;

        public static WeaponView Create(Camera cam, PlayerLook playerLook, PlayerMotor playerMotor)
        {
            var go = new GameObject("View");
            go.transform.SetParent(cam.transform, false);
            var v = go.AddComponent<WeaponView>();
            v.look = playerLook;
            v.motor = playerMotor;
            v.restPos = new Vector3(0.26f, -0.24f, 0.45f);

            v.modelRoot = new GameObject("ModelRoot").transform;
            v.modelRoot.SetParent(go.transform, false);
            v.modelRoot.localPosition = v.restPos;

            var flashGo = GameObject.CreatePrimitive(PrimitiveType.Quad);
            Destroy(flashGo.GetComponent<Collider>());
            flashGo.name = "MuzzleFlash";
            flashGo.transform.SetParent(v.modelRoot, false);
            flashGo.transform.localRotation = Quaternion.Euler(0f, 180f, 0f);
            flashGo.transform.localScale = new Vector3(0.22f, 0.22f, 0.22f);
            var mr = flashGo.GetComponent<MeshRenderer>();
            mr.sharedMaterial = new Material(Shader.Find("Sprites/Default")) { mainTexture = UiUtil.FlashTex() };
            mr.shadowCastingMode = ShadowCastingMode.Off;
            flashGo.SetActive(false);
            v.flash = flashGo.transform;

            return v;
        }

        // ЗАМЕНА ГРАФИКИ: модели оружия собраны из примитивов.
        // Здесь можно поставить меши из Kenney/Asset Store вместо Part(...).
        public void BuildModel(WeaponDef def, Material material)
        {
            mat = material;
            if (model != null) Destroy(model);
            model = new GameObject("Model");
            model.transform.SetParent(modelRoot, false);
            lowerTarget = 0f;
            lowerT = 0f;

            Vector3 muzzlePos = Vector3.zero;
            switch (def.Kind)
            {
                case WeaponKind.Rifle:
                    Part("receiver", new Vector3(0f, 0f, 0.10f), new Vector3(0.07f, 0.11f, 0.50f));
                    Part("barrel", new Vector3(0f, 0.01f, 0.42f), new Vector3(0.035f, 0.34f, 0.035f), true, 90f);
                    Part("mag", new Vector3(0f, -0.11f, 0.05f), new Vector3(0.05f, 0.16f, 0.08f), false, 8f);
                    Part("grip", new Vector3(0f, -0.10f, -0.12f), new Vector3(0.045f, 0.12f, 0.06f), false, 15f);
                    Part("stock", new Vector3(0f, -0.02f, -0.22f), new Vector3(0.05f, 0.09f, 0.18f));
                    Part("sightF", new Vector3(0f, 0.075f, 0.18f), new Vector3(0.02f, 0.03f, 0.02f));
                    Part("sightR", new Vector3(0f, 0.075f, 0.02f), new Vector3(0.02f, 0.03f, 0.02f));
                    muzzlePos = new Vector3(0f, 0.01f, 0.62f);
                    break;

                case WeaponKind.Smg:
                    Part("receiver", new Vector3(0f, 0f, 0.06f), new Vector3(0.07f, 0.10f, 0.38f));
                    Part("barrel", new Vector3(0f, 0.01f, 0.32f), new Vector3(0.03f, 0.20f, 0.03f), true, 90f);
                    Part("mag", new Vector3(0f, -0.13f, 0.04f), new Vector3(0.05f, 0.20f, 0.07f), false, 5f);
                    Part("grip", new Vector3(0f, -0.10f, -0.10f), new Vector3(0.045f, 0.12f, 0.06f), false, 15f);
                    muzzlePos = new Vector3(0f, 0.01f, 0.50f);
                    break;

                case WeaponKind.Sniper:
                    Part("receiver", new Vector3(0f, 0f, 0.12f), new Vector3(0.07f, 0.11f, 0.55f));
                    Part("barrel", new Vector3(0f, 0.01f, 0.50f), new Vector3(0.03f, 0.45f, 0.035f), true, 90f);
                    Part("scope", new Vector3(0f, 0.095f, 0.05f), new Vector3(0.045f, 0.22f, 0.045f), true, 90f);
                    Part("mag", new Vector3(0f, -0.10f, 0.06f), new Vector3(0.05f, 0.12f, 0.06f));
                    Part("stock", new Vector3(0f, -0.02f, -0.28f), new Vector3(0.05f, 0.10f, 0.20f));
                    muzzlePos = new Vector3(0f, 0.01f, 0.75f);
                    break;

                case WeaponKind.Pistol:
                    Part("receiver", new Vector3(0f, 0.02f, 0.10f), new Vector3(0.06f, 0.09f, 0.22f));
                    Part("barrel", new Vector3(0f, 0.03f, 0.25f), new Vector3(0.025f, 0.10f, 0.025f), true, 90f);
                    Part("grip", new Vector3(0f, -0.09f, 0.02f), new Vector3(0.045f, 0.13f, 0.06f), false, 12f);
                    muzzlePos = new Vector3(0f, 0.03f, 0.32f);
                    break;

                case WeaponKind.Knife:
                    Part("handle", new Vector3(0f, 0f, 0f), new Vector3(0.035f, 0.05f, 0.14f));
                    Part("blade", new Vector3(0f, 0.01f, 0.20f), new Vector3(0.012f, 0.05f, 0.26f));
                    muzzlePos = Vector3.zero;
                    break;
            }

            flash.localPosition = muzzlePos;
            flash.gameObject.SetActive(false);
        }

        void Part(string name, Vector3 pos, Vector3 scale, bool cylinder = false, float xRot = 0f)
        {
            var p = GameObject.CreatePrimitive(cylinder ? PrimitiveType.Cylinder : PrimitiveType.Cube);
            Destroy(p.GetComponent<Collider>());
            p.name = name;
            p.transform.SetParent(model.transform, false);
            p.transform.localPosition = pos;
            p.transform.localScale = scale;
            p.transform.localRotation = Quaternion.Euler(xRot, 0f, 0f);
            var r = p.GetComponent<MeshRenderer>();
            r.sharedMaterial = mat;
            r.shadowCastingMode = ShadowCastingMode.Off;
        }

        public void Kick() => kick = 1f;

        public void MuzzleFlash()
        {
            if (flash == null || !flash.gameObject.activeInHierarchy && flash.localPosition == Vector3.zero) return;
            flashT = 0.05f;
            flash.gameObject.SetActive(true);
        }

        public void PlayReload(float dur)
        {
            reloadDur = dur;
            reloadT = dur;
        }

        public void Lower() => lowerTarget = 1f;
        public void Raise() => lowerTarget = 0f;

        public void SetZoomVisible(bool visible) => modelRoot.gameObject.SetActive(!visible);

        void Update()
        {
            if (modelRoot == null) return;
            float dt = Time.deltaTime;

            float speed = motor != null ? new Vector2(motor.Velocity.x, motor.Velocity.z).magnitude : 0f;
            bobT += dt * (3f + speed * 1.6f);
            float bobAmp = Mathf.Clamp01(speed / GameConfig.MoveSpeed) * (look != null && look.Zoomed ? 0.004f : 0.012f);

            float swayTarget = look != null ? Mathf.Clamp(-look.LastLookDelta.x * 0.0006f, -0.03f, 0.03f) : 0f;
            swayX = Mathf.Lerp(swayX, swayTarget, dt * 10f);

            kick = Mathf.MoveTowards(kick, 0f, 240f * dt);

            float reloadRot = 0f, reloadDrop = 0f;
            if (reloadDur > 0f && reloadT > 0f)
            {
                reloadT -= dt;
                float phase = 1f - reloadT / reloadDur;
                float s = Mathf.Sin(phase * Mathf.PI);
                reloadRot = -28f * s;
                reloadDrop = -0.10f * s;
                if (reloadT <= 0f) reloadDur = 0f;
            }

            lowerT = Mathf.MoveTowards(lowerT, lowerTarget, dt / 0.18f);

            modelRoot.localPosition = restPos + new Vector3(
                swayX,
                Mathf.Sin(bobT * 2f) * bobAmp + reloadDrop - lowerT * 0.3f,
                0f);
            modelRoot.localRotation = Quaternion.Euler(
                kick * 4f + reloadRot + lowerT * 35f,
                swayX * 40f,
                Mathf.Sin(bobT) * bobAmp * 20f);

            if (flashT > 0f)
            {
                flashT -= dt;
                if (flashT <= 0f) flash.gameObject.SetActive(false);
            }
        }
    }
}
