using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace StrikeOps
{
    public sealed class TouchInput : MonoBehaviour
    {
        public Vector2 Move { get; private set; }
        public bool FireHeld => fireCount > 0;
        public bool UiBlocked { get; set; }

        Vector2 lookAccum;
        bool jumpQ, reloadQ, aimQ;
        int slotQ = -1;
        int slotActive, fireCount;

        RectTransform joyBase, joyKnob;
        readonly List<Image> slotChips = new List<Image>();
        Transform chipsRoot;
        readonly Color chipIdle = new Color(0.1f, 0.12f, 0.16f, 0.6f);
        readonly Color chipActive = new Color(0.95f, 0.6f, 0.1f, 0.9f);

        public static TouchInput Build(Transform canvasRoot)
        {
            var rootGo = new GameObject("TouchRoot", typeof(RectTransform));
            rootGo.transform.SetParent(canvasRoot, false);
            UiUtil.Stretch((RectTransform)rootGo.transform);
            var ti = rootGo.AddComponent<TouchInput>();

            // Полноэкранная зона обзора (нижний слой): получает все касания, кроме кнопок.
            var lookArea = UiUtil.MakeImage(rootGo.transform, "LookArea", UiUtil.White(), new Color(0f, 0f, 0f, 0f), raycast: true);
            UiUtil.Stretch(lookArea.rectTransform);
            var lookPad = lookArea.gameObject.AddComponent<LookPad>();
            lookPad.owner = ti;

            // Джойстик слева снизу.
            var joyBaseImg = UiUtil.MakeImage(rootGo.transform, "JoyBase", UiUtil.Ring(), new Color(1f, 1f, 1f, 0.4f), raycast: true);
            UiUtil.AnchorPoint(joyBaseImg.rectTransform, new Vector2(0f, 0f), new Vector2(190f, 190f), new Vector2(260f, 260f));
            var knob = UiUtil.MakeImage(joyBaseImg.transform, "Knob", UiUtil.Circle(), new Color(1f, 1f, 1f, 0.55f));
            UiUtil.AnchorPoint(knob.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(120f, 120f));
            knob.raycastTarget = false;
            var pad = joyBaseImg.gameObject.AddComponent<JoyPad>();
            pad.owner = ti;
            pad.baseRect = joyBaseImg.rectTransform;
            pad.knob = knob.rectTransform;

            ti.joyBase = joyBaseImg.rectTransform;
            ti.joyKnob = knob.rectTransform;

            // Контейнер слотов оружия.
            ti.chipsRoot = new GameObject("Slots", typeof(RectTransform)).transform;
            ti.chipsRoot.SetParent(rootGo.transform, false);
            UiUtil.Stretch((RectTransform)ti.chipsRoot);

            // Кнопки справа.
            ti.MakeHoldButton("FIRE", "ОГОНЬ", new Vector2(1f, 0f), new Vector2(-175f, 165f), 180f,
                new Color(0.9f, 0.25f, 0.2f, 0.55f), () => ti.fireCount++, () => ti.fireCount = Mathf.Max(0, ti.fireCount - 1));
            ti.MakeHoldButton("FIRE2", "ОГОНЬ", new Vector2(0f, 0f), new Vector2(350f, 430f), 110f,
                new Color(0.9f, 0.25f, 0.2f, 0.45f), () => ti.fireCount++, () => ti.fireCount = Mathf.Max(0, ti.fireCount - 1));
            ti.MakeHoldButton("ZOOM", "ЗУМ", new Vector2(1f, 0f), new Vector2(-345f, 110f), 115f,
                new Color(0.25f, 0.55f, 0.9f, 0.5f), () => ti.aimQ = true, null);
            ti.MakeHoldButton("JUMP", "ПРЫЖОК", new Vector2(1f, 0f), new Vector2(-115f, 375f), 115f,
                new Color(0.35f, 0.7f, 0.35f, 0.5f), () => ti.jumpQ = true, null);
            ti.MakeHoldButton("RELOAD", "ЗАРЯД", new Vector2(1f, 0f), new Vector2(-245f, 330f), 105f,
                new Color(0.8f, 0.65f, 0.2f, 0.5f), () => ti.reloadQ = true, null);
            ti.MakeHoldButton("SWITCH", "СМЕНА", new Vector2(1f, 0f), new Vector2(-345f, 250f), 105f,
                new Color(0.55f, 0.4f, 0.75f, 0.5f), () => ti.slotQ = (ti.slotActive + 1) % Mathf.Max(1, ti.slotChips.Count), null);

            return ti;
        }

        void MakeHoldButton(string name, string label, Vector2 anchor, Vector2 pos, float size, Color color, System.Action down, System.Action up)
        {
            var img = UiUtil.MakeImage(transform, name, UiUtil.Circle(), color, raycast: true);
            UiUtil.AnchorPoint(img.rectTransform, anchor, pos, new Vector2(size, size));
            var t = UiUtil.MakeText(img.transform, "label", label, Mathf.RoundToInt(size * 0.16f), Color.white, TextAnchor.MiddleCenter);
            UiUtil.Stretch(t.rectTransform);
            var hold = img.gameObject.AddComponent<HoldButton>();
            hold.owner = this;
            hold.Down = down;
            hold.Up = up;
        }

        public void SetSlotCount(int n)
        {
            foreach (Transform child in chipsRoot)
                Destroy(child.gameObject);
            slotChips.Clear();

            var defs = GameConfig.Loadout();
            for (int i = 0; i < n && i < defs.Length; i++)
            {
                int slotIndex = i;
                var chip = UiUtil.MakeButton(chipsRoot, "slot" + i, UiUtil.White(), chipIdle, () => slotQ = slotIndex);
                UiUtil.AnchorPoint(chip.GetComponent<RectTransform>(), new Vector2(0.5f, 0f),
                    new Vector2(680f + i * 140f, 46f), new Vector2(132f, 44f));
                var t = UiUtil.MakeText(chip.transform, "label", (i + 1) + " " + defs[i].ShortName, 20, Color.white, TextAnchor.MiddleCenter);
                UiUtil.Stretch(t.rectTransform);
                slotChips.Add(chip.GetComponent<Image>());
            }
            SetSlotActive(0);
        }

        public void SetSlotActive(int i)
        {
            slotActive = i;
            for (int c = 0; c < slotChips.Count; c++)
                slotChips[c].color = c == i ? chipActive : chipIdle;
        }

        public Vector2 ConsumeLook()
        {
            var v = lookAccum;
            lookAccum = Vector2.zero;
            return v;
        }

        public bool ConsumeJump() { bool v = jumpQ; jumpQ = false; return v; }
        public bool ConsumeReload() { bool v = reloadQ; reloadQ = false; return v; }
        public bool ConsumeAimToggle() { bool v = aimQ; aimQ = false; return v; }
        public int ConsumeSlot() { int v = slotQ; slotQ = -1; return v; }

        public void SetMove(Vector2 v) => Move = v;
        public void AddLook(Vector2 d) => lookAccum += d;

        public void ForceRelease()
        {
            fireCount = 0;
            Move = Vector2.zero;
            jumpQ = reloadQ = aimQ = false;
            slotQ = -1;
            lookAccum = Vector2.zero;
            if (joyKnob != null) joyKnob.anchoredPosition = Vector2.zero;
        }

        sealed class LookPad : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
        {
            public TouchInput owner;
            int pid = -1;
            Vector2 last;

            public void OnPointerDown(PointerEventData e)
            {
                if (owner.UiBlocked || pid != -1) return;
                pid = e.pointerId;
                last = e.position;
            }

            public void OnDrag(PointerEventData e)
            {
                if (owner.UiBlocked || e.pointerId != pid) return;
                owner.AddLook(e.position - last);
                last = e.position;
            }

            public void OnPointerUp(PointerEventData e)
            {
                if (e.pointerId == pid) pid = -1;
            }
        }

        sealed class JoyPad : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
        {
            public TouchInput owner;
            public RectTransform baseRect, knob;
            const float Radius = 105f;
            int pid = -1;

            public void OnPointerDown(PointerEventData e)
            {
                if (owner.UiBlocked) return;
                pid = e.pointerId;
                Drag(e);
            }

            public void OnDrag(PointerEventData e)
            {
                if (owner.UiBlocked || e.pointerId != pid) return;
                Drag(e);
            }

            void Drag(PointerEventData e)
            {
                RectTransformUtility.ScreenPointToLocalPointInRectangle(baseRect, e.position, e.pressEventCamera, out var lp);
                var v = Vector2.ClampMagnitude(lp, Radius);
                knob.anchoredPosition = v;
                owner.SetMove(v / Radius);
            }

            public void OnPointerUp(PointerEventData e)
            {
                if (e.pointerId != pid) return;
                pid = -1;
                knob.anchoredPosition = Vector2.zero;
                owner.SetMove(Vector2.zero);
            }
        }

        sealed class HoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
        {
            public TouchInput owner;
            public System.Action Down, Up;

            public void OnPointerDown(PointerEventData e)
            {
                if (owner != null && owner.UiBlocked) return;
                Down?.Invoke();
            }

            public void OnPointerUp(PointerEventData e) => Up?.Invoke();
            public void OnPointerExit(PointerEventData e) => Up?.Invoke();
        }
    }
}
