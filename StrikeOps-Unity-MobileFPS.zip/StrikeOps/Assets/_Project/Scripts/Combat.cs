using System;
using System.Collections.Generic;
using UnityEngine;

namespace StrikeOps
{
    public enum HitZone { Body, Head }

    public struct HitInfo
    {
        public float Damage;
        public HitZone Zone;
        public int AttackerId;
        public string AttackerName;
        public string WeaponName;
        public Vector3 Point;
        public Vector3 Normal;
    }

    public interface IDamageable
    {
        int Id { get; }
        string DisplayName { get; }
        bool IsAlive { get; }
        Vector3 AimPoint { get; }
        void ReceiveHit(HitInfo hit);
        event Action<HitInfo> Died;
    }

    public static class CombatantRegistry
    {
        static readonly List<IDamageable> all = new List<IDamageable>();

        public static IReadOnlyList<IDamageable> All => all;

        public static void Register(IDamageable c)
        {
            if (!all.Contains(c)) all.Add(c);
        }

        public static void Unregister(IDamageable c)
        {
            all.Remove(c);
        }

        public static IDamageable ById(int id)
        {
            for (int i = 0; i < all.Count; i++)
                if (all[i].Id == id) return all[i];
            return null;
        }

        public static void Clear() => all.Clear();
    }

    public static class CombatUtil
    {
        public static IDamageable FindVictim(Collider col)
        {
            var bot = col.GetComponentInParent<BotHealth>();
            if (bot != null) return bot;
            var player = col.GetComponentInParent<PlayerHealth>();
            if (player != null) return player;
            return null;
        }

        public static HitZone ZoneFromPoint(Collider col, Vector3 point)
        {
            float topOffset = col.bounds.max.y - point.y;
            return topOffset <= GameConfig.HeadZoneHeight ? HitZone.Head : HitZone.Body;
        }
    }
}
