using System;
using UnityEngine;

namespace StrikeOps
{
    public sealed class BotHealth : MonoBehaviour, IDamageable
    {
        public int Id { get; private set; }
        public string DisplayName { get; private set; }
        public bool IsAlive => hp > 0f;
        public Vector3 AimPoint => transform.position + Vector3.up * 1.45f;

        public event Action<HitInfo> Died;

        float hp = 100f;
        MatchState match;

        public void Init(int id, string name, MatchState m)
        {
            Id = id;
            DisplayName = name;
            match = m;
            CombatantRegistry.Register(this);
        }

        void OnDestroy() => CombatantRegistry.Unregister(this);

        public void ReceiveHit(HitInfo hit)
        {
            if (!IsAlive || !match.Running) return;

            hp -= hit.Damage;
            if (hp <= 0f)
            {
                hp = 0f;
                match.RegisterKill(hit.AttackerId, hit.AttackerName, this, hit.WeaponName, hit.Zone == HitZone.Head);
                Died?.Invoke(hit);
            }
        }

        public void Revive() => hp = 100f;
    }
}
