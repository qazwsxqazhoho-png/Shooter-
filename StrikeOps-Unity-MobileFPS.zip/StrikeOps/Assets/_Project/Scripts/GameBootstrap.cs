using UnityEngine;

namespace StrikeOps
{
    public sealed class GameBootstrap : MonoBehaviour
    {
        MatchState match;

        void Awake()
        {
            Application.targetFrameRate = 60;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;

            Screen.autorotateToPortrait = false;
            Screen.autorotateToPortraitUpsideDown = false;
            Screen.autorotateToLandscapeLeft = true;
            Screen.autorotateToLandscapeRight = true;
            if (Screen.height > Screen.width)
                Screen.orientation = ScreenOrientation.LandscapeLeft;

            CombatantRegistry.Clear();

            var systemsRoot = new GameObject("Systems").transform;
            var fx = systemsRoot.gameObject.AddComponent<FxSystem>();

            var map = MapBuilder.Build(systemsRoot);
            match = new MatchState(GameConfig.TargetScore, GameConfig.MatchSeconds);
            var skins = new SkinDatabase();

            var canvas = UiFactory.Create("UIRoot");
            var touch = TouchInput.Build(canvas);
            var hud = HudView.Build(canvas);
            var pause = PauseOverlay.Build(canvas);

            var player = PlayerFactory.Create(map, match, touch, hud, fx, skins);
            BotFactory.CreateAll(map, match, fx, GameConfig.BotCount, systemsRoot);

            hud.Bind(match, player.Health, player.Weapons, player.Look);
            pause.Init(touch, skins, match);
            pause.SetWeapons(player.Weapons);

            match.Begin();
        }

        void Update()
        {
            if (match != null)
                match.Tick(Time.deltaTime);
        }
    }
}
