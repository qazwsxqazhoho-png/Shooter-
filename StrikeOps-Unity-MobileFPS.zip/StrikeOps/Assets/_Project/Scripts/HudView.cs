using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace StrikeOps
{
    public sealed class HudView : MonoBehaviour
    {
        MatchState match;
        PlayerHealth health;
        WeaponSystem weapons;
        PlayerLook look;

        Text timerText, scoreText, hpText, armorText, ammoText, weaponText, reloadText;
        Text killerText, respawnText, titleText, standingsText, hintText;
        Image hpFill, armorFill, vignette;
        Image crossUp, crossDown, crossLeft, crossRight, crossDot;
        Image[] hitLines;
        GameObject scope, deathOverlay, endOverlay, crosshairRoot;
        AudioSource src;

        float hitAlpha, hitFlash, vignFlash;
        int kfCount, lastTimerSec = -1;

        public static HudView Build(Transform canvasRoot)
        {
            var go = new GameObject("HUD", typeof(RectTransform));
            go.transform.SetParent(canvasRoot, false);
            UiUtil.Stretch((RectTransform)go.transform);
            var h = go.AddComponent<HudView>();
            h.BuildUi();
            return h;
        }

        void BuildUi()
        {
            src = gameObject.AddComponent<AudioSource>();
            src.spatialBlend = 0f;
            src.playOnAwake = false;
            src.volume = 0.7f;

            var ui = transform;

            timerText = UiUtil.MakeText(ui, "timer", "5:00", 34, Color.white, TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(timerText.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -28f), new Vector2(220f, 44f));

            scoreText = UiUtil.MakeText(ui, "score", "Вы: 0 • Лидер: -", 22, new Color(1f, 1f, 1f, 0.9f), TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(scoreText.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -76f), new Vector2(640f, 30f));

            hintText = UiUtil.MakeText(ui, "hint",
                "Левый джойстик - движение • Свайп по экрану - обзор • ОГОНЬ - стрельба",
                22, new Color(1f, 1f, 1f, 0.95f), TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(hintText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 280f), new Vector2(1400f, 30f));
            StartCoroutine(FadeHint());

            BuildBars();
            BuildAmmo();
            BuildCrosshair();
            BuildHitmarker();

            vignette = UiUtil.MakeImage(ui, "vignette", UiUtil.VignetteSprite(), new Color(1f, 0.12f, 0.1f, 0f));
            UiUtil.Stretch(vignette.rectTransform);

            scope = UiUtil.MakeImage(ui, "scope", UiUtil.ScopeSprite(), Color.white).gameObject;
            UiUtil.Stretch(scope.GetComponent<RectTransform>());
            scope.SetActive(false);

            BuildDeathOverlay();
            BuildEndOverlay();
        }

        void BuildBars()
        {
            hpFill = MakeBar("hp", 415f, new Color(0.2f, 0.85f, 0.3f), out hpText);
            armorFill = MakeBar("armor", 380f, new Color(0.3f, 0.6f, 0.95f), out armorText);
        }

        Image MakeBar(string name, float y, Color fillColor, out Text label)
        {
            var bg = UiUtil.MakeImage(transform, name + "Bg", UiUtil.White(), new Color(0f, 0f, 0f, 0.45f));
            UiUtil.AnchorPoint(bg.rectTransform, new Vector2(0f, 0f), new Vector2(195f, y), new Vector2(300f, 26f));

            var fill = UiUtil.MakeImage(bg.transform, name + "Fill", UiUtil.White(), fillColor);
            UiUtil.Stretch(fill.rectTransform);
            fill.rectTransform.offsetMin = new Vector2(3f, 3f);
            fill.rectTransform.offsetMax = new Vector2(-3f, -3f);
            fill.type = Image.Type.Filled;
            fill.fillMethod = Image.FillMethod.Horizontal;
            fill.fillOrigin = (int)Image.OriginHorizontal.Left;
            fill.fillAmount = 1f;

            label = UiUtil.MakeText(bg.transform, name + "Label", "100", 18, Color.white, TextAnchor.MiddleCenter);
            UiUtil.Stretch(label.rectTransform);
            return fill;
        }

        void BuildAmmo()
        {
            ammoText = UiUtil.MakeText(transform, "ammo", "30 / 120", 38, Color.white, TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(ammoText.rectTransform, new Vector2(1f, 0f), new Vector2(-190f, 470f), new Vector2(340f, 50f));

            weaponText = UiUtil.MakeText(transform, "weapon", "", 20, new Color(1f, 1f, 1f, 0.85f), TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(weaponText.rectTransform, new Vector2(1f, 0f), new Vector2(-190f, 530f), new Vector2(560f, 26f));

            reloadText = UiUtil.MakeText(transform, "reload", "ПЕРЕЗАРЯДКА...", 24, new Color(1f, 0.85f, 0.3f), TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(reloadText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, -140f), new Vector2(400f, 30f));
            reloadText.gameObject.SetActive(false);
        }

        void BuildCrosshair()
        {
            crosshairRoot = new GameObject("Crosshair", typeof(RectTransform));
            crosshairRoot.transform.SetParent(transform, false);
            UiUtil.Stretch((RectTransform)crosshairRoot.transform);

            var col = new Color(1f, 1f, 1f, 0.9f);
            crossUp = MakeLine(crosshairRoot.transform, new Vector3(0f, 14f, 0f), new Vector2(3f, 14f), 0f, col);
            crossDown = MakeLine(crosshairRoot.transform, new Vector3(0f, -14f, 0f), new Vector2(3f, 14f), 0f, col);
            crossLeft = MakeLine(crosshairRoot.transform, new Vector3(-14f, 0f, 0f), new Vector2(14f, 3f), 0f, col);
            crossRight = MakeLine(crosshairRoot.transform, new Vector3(14f, 0f, 0f), new Vector2(14f, 3f), 0f, col);
            crossDot = UiUtil.MakeImage(crosshairRoot.transform, "dot", UiUtil.White(), col);
            UiUtil.AnchorPoint(crossDot.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(4f, 4f));
        }

        Image MakeLine(Transform parent, Vector3 pos, Vector2 size, float rot, Color col)
        {
            var img = UiUtil.MakeImage(parent, "line", UiUtil.White(), col);
            UiUtil.AnchorPoint(img.rectTransform, new Vector2(0.5f, 0.5f), pos, size);
            img.rectTransform.localRotation = Quaternion.Euler(0f, 0f, rot);
            return img;
        }

        void BuildHitmarker()
        {
            hitLines = new Image[4];
            Vector2[] pos = { new Vector2(10f, 10f), new Vector2(-10f, -10f), new Vector2(-10f, 10f), new Vector2(10f, -10f) };
            float[] rot = { 45f, 45f, -45f, -45f };
            for (int i = 0; i < 4; i++)
            {
                hitLines[i] = MakeLine(transform, pos[i], new Vector2(3f, 14f), rot[i], new Color(1f, 1f, 1f, 0f));
            }
        }

        void BuildDeathOverlay()
        {
            deathOverlay = new GameObject("DeathOverlay", typeof(RectTransform));
            deathOverlay.transform.SetParent(transform, false);
            UiUtil.Stretch((RectTransform)deathOverlay.transform);

            var dim = UiUtil.MakeImage(deathOverlay.transform, "dim", UiUtil.White(), new Color(0.25f, 0.02f, 0.02f, 0.5f));
            UiUtil.Stretch(dim.rectTransform);

            killerText = UiUtil.MakeText(deathOverlay.transform, "killer", "", 30, Color.white, TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(killerText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 50f), new Vector2(1000f, 40f));

            respawnText = UiUtil.MakeText(deathOverlay.transform, "resp", "", 24, new Color(1f, 1f, 1f, 0.85f), TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(respawnText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, -10f), new Vector2(1000f, 34f));

            deathOverlay.SetActive(false);
        }

        void BuildEndOverlay()
        {
            endOverlay = new GameObject("EndOverlay", typeof(RectTransform));
            endOverlay.transform.SetParent(transform, false);
            UiUtil.Stretch((RectTransform)endOverlay.transform);

            var dim = UiUtil.MakeImage(endOverlay.transform, "dim", UiUtil.White(), new Color(0f, 0f, 0f, 0.78f));
            UiUtil.Stretch(dim.rectTransform);

            titleText = UiUtil.MakeText(endOverlay.transform, "title", "", 46, Color.white, TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(titleText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 200f), new Vector2(900f, 60f));

            standingsText = UiUtil.MakeText(endOverlay.transform, "standings", "", 26, new Color(1f, 1f, 1f, 0.95f), TextAnchor.MiddleCenter);
            UiUtil.AnchorPoint(standingsText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 0f), new Vector2(900f, 320f));

            var btn = UiUtil.MakeButton(endOverlay.transform, "restart", UiUtil.White(), new Color(0.15f, 0.55f, 0.25f, 0.95f), () => RestartMatch());
            UiUtil.AnchorPoint(btn.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f), new Vector2(0f, -240f), new Vector2(380f, 80f));

            var btnLabel = UiUtil.MakeText(btn.transform, "label", "Играть снова", 28, Color.white, TextAnchor.MiddleCenter);
            UiUtil.Stretch(btnLabel.rectTransform);

            endOverlay.SetActive(false);
        }

        void RestartMatch()
        {
            if (match != null) match.Restart();
        }

        public void Bind(MatchState m, PlayerHealth h, WeaponSystem w, PlayerLook l)
        {
            match = m;
            health = h;
            weapons = w;
            look = l;

            match.KillFed += OnKill;
            match.Ended += OnEnd;
            weapons.StateChanged += UpdateAmmo;
            UpdateAmmo();
            UpdateScoreLine();
        }

        void UpdateAmmo()
        {
            if (weapons == null) return;
            ammoText.text = weapons.Current.Melee ? "-" : weapons.Mag + " / " + weapons.Reserve;
            weaponText.text = weapons.Current.Name;
        }

        void UpdateScoreLine()
        {
            if (match == null) return;
            int my = match.GetScore(MatchState.PlayerId);
            string leaderName = "-";
            int leaderScore = 0;
            foreach (var c in CombatantRegistry.All)
            {
                if (c.Id == MatchState.PlayerId) continue;
                int s = match.GetScore(c.Id);
                if (s > leaderScore)
                {
                    leaderScore = s;
                    leaderName = c.DisplayName;
                }
            }
            scoreText.text = "Вы: " + my + " • Лидер: " + leaderName + " " + leaderScore;
        }

        public void DamageFlash() => vignFlash = 0.55f;

        public void OnPlayerHitConfirmed()
        {
            ShowHitmarker(false);
            SoundFactory.Play(src, Sfx.Hit);
        }

        void ShowHitmarker(bool kill)
        {
            hitAlpha = 1f;
            hitFlash = kill ? 1f : 0f;
            var c = kill ? new Color(1f, 0.25f, 0.2f, hitAlpha) : new Color(1f, 1f, 1f, hitAlpha);
            for (int i = 0; i < hitLines.Length; i++) hitLines[i].color = c;
        }

        void OnKill(KillFeedEntry e)
        {
            AddKillFeed(e);
            UpdateScoreLine();
            if (e.KillerId == MatchState.PlayerId)
            {
                ShowHitmarker(true);
                SoundFactory.Play(src, Sfx.Kill);
            }
        }

        void AddKillFeed(KillFeedEntry e)
        {
            var col = e.KillerId == MatchState.PlayerId ? new Color(0.4f, 1f, 0.45f)
                    : e.Victim == "Вы" ? new Color(1f, 0.45f, 0.4f)
                    : new Color(1f, 1f, 1f, 0.9f);

            string head = e.Head ? " [в голову]" : "";
            var t = UiUtil.MakeText(transform, "kf", e.Killer + "  [" + e.Weapon + "]" + head + "  >  " + e.Victim,
                22, col, TextAnchor.UpperRight);
            var rt = t.rectTransform;
            rt.anchorMin = new Vector2(1f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(1f, 1f);
            rt.anchoredPosition = new Vector2(-30f, -110f - (kfCount % 6) * 32f);
            rt.sizeDelta = new Vector2(10f, 30f);

            kfCount++;
            StartCoroutine(FadeEntry(t, col));
        }

        IEnumerator FadeEntry(Text t, Color col)
        {
            yield return new WaitForSeconds(4f);
            float a = 1f;
            while (a > 0f)
            {
                a -= Time.deltaTime * 1.5f;
                col.a = Mathf.Max(0f, a);
                t.color = col;
                yield return null;
            }
            Destroy(t.gameObject);
        }

        IEnumerator FadeHint()
        {
            yield return new WaitForSeconds(7f);
            float a = 1f;
            var col = hintText.color;
            while (a > 0f)
            {
                a -= Time.deltaTime * 0.8f;
                col.a = Mathf.Max(0f, a);
                hintText.color = col;
                yield return null;
            }
            hintText.gameObject.SetActive(false);
        }

        void OnEnd(System.Collections.Generic.List<MatchState.Standing> standings)
        {
            endOverlay.SetActive(true);
            deathOverlay.SetActive(false);

            bool win = standings.Count > 0 && standings[0].IsPlayer;
            titleText.text = win ? "ПОБЕДА!" : "МАТЧ ЗАВЕРШЁН";
            titleText.color = win ? new Color(0.45f, 1f, 0.55f) : Color.white;

            var sb = new StringBuilder();
            for (int i = 0; i < standings.Count; i++)
            {
                var s = standings[i];
                sb.Append(i + 1).Append(". ").Append(s.Name).Append(" — ").Append(s.Score);
                if (s.IsPlayer) sb.Append("  (Вы)");
                if (i < standings.Count - 1) sb.Append('\n');
            }
            standingsText.text = sb.ToString();

            if (Cursor.lockState == CursorLockMode.Locked)
                Cursor.lockState = CursorLockMode.None;
        }

        void Update()
        {
            if (match != null)
            {
                int sec = Mathf.CeilToInt(match.TimeLeft);
                if (sec != lastTimerSec)
                {
                    lastTimerSec = sec;
                    timerText.text = (sec / 60) + ":" + (sec % 60).ToString("00");
                }
            }

            if (health != null)
            {
                float hpFill01 = Mathf.Clamp01(health.Hp / 100f);
                hpFill.fillAmount = hpFill01;
                hpFill.color = Color.Lerp(new Color(0.9f, 0.2f, 0.15f), new Color(0.2f, 0.85f, 0.3f), hpFill01);
                hpText.text = Mathf.CeilToInt(health.Hp).ToString();

                armorFill.fillAmount = Mathf.Clamp01(health.Armor / 50f);
                armorText.text = Mathf.CeilToInt(health.Armor).ToString();

                deathOverlay.SetActive(health.Dead);
                if (health.Dead)
                {
                    respawnText.text = "Возрождение через " + Mathf.CeilToInt(Mathf.Max(0f, health.RespawnTimer));
                }

                float lowHp = health.Hp < 35f ? (35f - health.Hp) / 35f * 0.35f : 0f;
                var vc = vignette.color;
                vc.a = Mathf.Clamp01(lowHp + vignFlash);
                vignette.color = vc;
            }
            vignFlash = Mathf.MoveTowards(vignFlash, 0f, Time.deltaTime * 1.2f);

            if (weapons != null)
            {
                reloadText.gameObject.SetActive(weapons.IsReloading);
                if (weapons.IsReloading)
                {
                    var rc = reloadText.color;
                    rc.a = 0.65f + 0.35f * Mathf.Sin(Time.time * 8f);
                    reloadText.color = rc;
                }

                bool hideCross = (look != null && look.Zoomed)
                    || (health != null && health.Dead)
                    || weapons.Current.Melee;
                crosshairRoot.SetActive(!hideCross);

                float gap = 10f + weapons.CurrentSpreadDeg * 9f;
                crossUp.rectTransform.anchoredPosition = new Vector2(0f, gap + 7f);
                crossDown.rectTransform.anchoredPosition = new Vector2(0f, -(gap + 7f));
                crossLeft.rectTransform.anchoredPosition = new Vector2(-(gap + 7f), 0f);
                crossRight.rectTransform.anchoredPosition = new Vector2(gap + 7f, 0f);
            }

            if (look != null)
                scope.SetActive(look.Zoomed);

            if (hitAlpha > 0f)
            {
                hitAlpha = Mathf.Max(0f, hitAlpha - Time.deltaTime * 3.5f);
                for (int i = 0; i < hitLines.Length; i++)
                {
                    var c = hitLines[i].color;
                    c.a = hitAlpha;
                    hitLines[i].color = c;
                }
            }
        }
    }
}
