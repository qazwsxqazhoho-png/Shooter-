using UnityEngine;

namespace StrikeOps
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class PlayerMotor : MonoBehaviour
    {
        public bool Enabled = true;
        public bool Grounded => cc != null && cc.isGrounded;
        public Vector3 Velocity => cc != null ? cc.velocity : Vector3.zero;

        TouchInput touch;
        PlayerLook look;
        CharacterController cc;
        float velY;

        public void Init(TouchInput touchInput, PlayerLook playerLook)
        {
            touch = touchInput;
            look = playerLook;
            cc = GetComponent<CharacterController>();
        }

        public void ResetVertical() => velY = 0f;

        void Update()
        {
            bool active = Time.timeScale > 0f && Enabled;
            Vector2 move = Vector2.zero;

            if (active)
            {
                if (touch != null) move = touch.Move;

                if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) move.y += 1f;
                if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) move.y -= 1f;
                if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) move.x -= 1f;
                if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) move.x += 1f;

                if (move.sqrMagnitude > 1f) move.Normalize();

                bool jump = (touch != null && touch.ConsumeJump()) || Input.GetKeyDown(KeyCode.Space);
                if (jump && cc.isGrounded)
                    velY = GameConfig.JumpVelocity;
            }

            float speed = GameConfig.MoveSpeed * (look != null && look.Zoomed ? 0.55f : 1f);
            Vector3 horizontal = (transform.right * move.x + transform.forward * move.y) * speed;

            velY -= GameConfig.Gravity * Time.deltaTime;
            if (cc.isGrounded && velY < 0f) velY = -1.5f;

            Vector3 delta = horizontal + Vector3.up * velY;
            cc.Move(delta * Time.deltaTime);
        }
    }
}
