using UnityEngine;

namespace StrikeOps
{
    public enum WeaponKind { Rifle, Smg, Sniper, Pistol, Knife }

    public sealed class WeaponDef
    {
        public string Name;
        public string ShortName;
        public WeaponKind Kind;
        public float Damage;
        public float Rpm;
        public int MagSize;
        public int Reserve;
        public float ReloadTime;
        public float Range;
        public float HeadMul;
        public float SpreadHip;
        public float SpreadZoom;
        public float BloomPerShot;
        public float MaxBloom;
        public float RecoilV;
        public float RecoilH;
        public float FalloffStart;
        public float FalloffEnd;
        public float MinDamageFactor;
        public bool Auto;
        public bool Melee;
        public float ZoomFov;
    }

    public static class GameConfig
    {
        public const int TargetScore = 20;
        public const float MatchSeconds = 300f;
        public const float RespawnDelay = 3f;
        public const int BotCount = 5;

        public const float MoveSpeed = 5.2f;
        public const float JumpVelocity = 5.0f;
        public const float Gravity = 16f;

        public const float HeadZoneHeight = 0.32f;
        public const float MouseSensitivity = 2.4f;
        public const float TouchSensitivity = 0.09f;
        public const float ZoomSensFactor = 0.45f;

        public static float SensScale
        {
            get => PlayerPrefs.GetFloat("sens", 1f);
            set
            {
                PlayerPrefs.SetFloat("sens", Mathf.Clamp(value, 0.4f, 3f));
                PlayerPrefs.Save();
            }
        }

        public static WeaponDef MakeRifle() => new WeaponDef
        {
            Name = "Автомат «Шторм»", ShortName = "Шторм", Kind = WeaponKind.Rifle,
            Damage = 26f, Rpm = 600f, MagSize = 30, Reserve = 120, ReloadTime = 2.2f,
            Range = 70f, HeadMul = 2.5f, SpreadHip = 0.9f, SpreadZoom = 0.9f,
            BloomPerShot = 0.30f, MaxBloom = 3.2f, RecoilV = 0.55f, RecoilH = 0.16f,
            FalloffStart = 25f, FalloffEnd = 55f, MinDamageFactor = 0.65f,
            Auto = true, ZoomFov = 0f
        };

        public static WeaponDef MakeSmg() => new WeaponDef
        {
            Name = "Пистолет-пулемёт «Оса»", ShortName = "Оса", Kind = WeaponKind.Smg,
            Damage = 19f, Rpm = 900f, MagSize = 35, Reserve = 140, ReloadTime = 2.0f,
            Range = 45f, HeadMul = 2.0f, SpreadHip = 1.3f, SpreadZoom = 1.3f,
            BloomPerShot = 0.22f, MaxBloom = 2.6f, RecoilV = 0.38f, RecoilH = 0.22f,
            FalloffStart = 12f, FalloffEnd = 30f, MinDamageFactor = 0.6f,
            Auto = true, ZoomFov = 0f
        };

        public static WeaponDef MakeSniper() => new WeaponDef
        {
            Name = "Снайперская винтовка «Сокол»", ShortName = "Сокол", Kind = WeaponKind.Sniper,
            Damage = 105f, Rpm = 45f, MagSize = 5, Reserve = 25, ReloadTime = 3.2f,
            Range = 150f, HeadMul = 2.0f, SpreadHip = 4.5f, SpreadZoom = 0.06f,
            BloomPerShot = 0f, MaxBloom = 0f, RecoilV = 2.4f, RecoilH = 0.4f,
            FalloffStart = 1000f, FalloffEnd = 1000f, MinDamageFactor = 1f,
            Auto = false, ZoomFov = 18f
        };

        public static WeaponDef MakePistol() => new WeaponDef
        {
            Name = "Пистолет «Гадюка»", ShortName = "Гадюка", Kind = WeaponKind.Pistol,
            Damage = 24f, Rpm = 380f, MagSize = 12, Reserve = 60, ReloadTime = 1.6f,
            Range = 50f, HeadMul = 2.5f, SpreadHip = 1.1f, SpreadZoom = 1.1f,
            BloomPerShot = 0.35f, MaxBloom = 2.4f, RecoilV = 0.55f, RecoilH = 0.18f,
            FalloffStart = 15f, FalloffEnd = 35f, MinDamageFactor = 0.65f,
            Auto = false, ZoomFov = 0f
        };

        public static WeaponDef MakeKnife() => new WeaponDef
        {
            Name = "Нож «Клинок»", ShortName = "Клинок", Kind = WeaponKind.Knife,
            Damage = 55f, Rpm = 120f, MagSize = 0, Reserve = 0, ReloadTime = 0f,
            Range = 2.3f, HeadMul = 1.5f, SpreadHip = 0f, SpreadZoom = 0f,
            BloomPerShot = 0f, MaxBloom = 0f, RecoilV = 0.8f, RecoilH = 0f,
            FalloffStart = 1000f, FalloffEnd = 1000f, MinDamageFactor = 1f,
            Auto = false, Melee = true, ZoomFov = 0f
        };

        public static WeaponDef[] Loadout() => new[]
        {
            MakeRifle(), MakeSmg(), MakeSniper(), MakePistol(), MakeKnife()
        };

        public static WeaponDef MakeBotRifle() => new WeaponDef
        {
            Name = "Шторм (бот)", ShortName = "Шторм", Kind = WeaponKind.Rifle,
            Damage = 14f, Rpm = 400f, MagSize = 999, Reserve = 0, ReloadTime = 0f,
            Range = 60f, HeadMul = 1.6f, SpreadHip = 3.4f, SpreadZoom = 3.4f,
            BloomPerShot = 0f, MaxBloom = 0f, RecoilV = 0f, RecoilH = 0f,
            FalloffStart = 20f, FalloffEnd = 50f, MinDamageFactor = 0.6f,
            Auto = true, ZoomFov = 0f
        };
    }
}
