using System;
using UnityEngine;
using UnityEngine.UI;

namespace StrikeOps
{
    public static class UiFactory
    {
        public static Transform Create(string name)
        {
            var go = new GameObject(name, typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = go.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;

            var scaler = go.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 1f;

            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            return go.transform;
        }
    }

    public static class UiUtil
    {
        static Font font;

        public static Font ResolveFont()
        {
            if (font != null) return font;
            try
            {
                font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                if (font != null) return font;
            }
            catch { /* fallback below */ }
            try
            {
                font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                if (font != null) return font;
            }
            catch { /* fallback below */ }
            font = Font.CreateDynamicFontFromOSFont("Arial", 16);
            return font;
        }

        public delegate Color32 PixelFn(int x, int y);

        public static Texture2D MakeTex(int w, int h, PixelFn fn)
        {
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false)
            {
                filterMode = FilterMode.Bilinear,
                wrapMode = TextureWrapMode.Clamp
            };
            var px = new Color32[w * h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    px[y * w + x] = fn(x, y);
            tex.SetPixels32(px);
            tex.Apply();
            return tex;
        }

        static Texture2D whiteTex;
        public static Sprite White()
        {
            if (whiteTex == null)
                whiteTex = MakeTex(4, 4, (x, y) => new Color32(255, 255, 255, 255));
            return SpriteOf(whiteTex);
        }

        static Texture2D circleTex;
        public static Sprite Circle()
        {
            if (circleTex == null)
                circleTex = MakeTex(64, 64, (x, y) =>
                {
                    float d = Vector2.Distance(new Vector2(x, y), new Vector2(31.5f, 31.5f)) / 32f;
                    float a = Mathf.Clamp01((1f - d) / 0.08f);
                    return new Color32(255, 255, 255, (byte)Mathf.RoundToInt(a * 255f));
                });
            return SpriteOf(circleTex);
        }

        static Texture2D ringTex;
        public static Sprite Ring()
        {
            if (ringTex == null)
                ringTex = MakeTex(64, 64, (x, y) =>
                {
                    float d = Vector2.Distance(new Vector2(x, y), new Vector2(31.5f, 31.5f)) / 32f;
                    float a = Mathf.Clamp01(Mathf.Min(d - 0.72f, 0.98f - d) / 0.06f);
                    return new Color32(255, 255, 255, (byte)Mathf.RoundToInt(a * 255f));
                });
            return SpriteOf(ringTex);
        }

        static Texture2D vignetteTex;
        public static Sprite VignetteSprite()
        {
            if (vignetteTex == null)
                vignetteTex = MakeTex(256, 256, (x, y) =>
                {
                    float r = Vector2.Distance(new Vector2(x, y), new Vector2(127.5f, 127.5f)) / (128f * 1.35f);
                    float a = Mathf.Clamp01((r - 0.5f) / 0.5f);
                    a *= a;
                    return new Color32(255, 255, 255, (byte)Mathf.RoundToInt(a * 255f));
                });
            return SpriteOf(vignetteTex);
        }

        static Texture2D scopeTex;
        public static Sprite ScopeSprite()
        {
            if (scopeTex == null)
                scopeTex = MakeTex(512, 512, (x, y) =>
                {
                    float d = Vector2.Distance(new Vector2(x, y), new Vector2(255.5f, 255.5f));
                    if (d < 172f)
                    {
                        bool cross = Mathf.Abs(x - 255.5f) < 1.5f || Mathf.Abs(y - 255.5f) < 1.5f;
                        return cross ? new Color32(230, 230, 230, 220) : new Color32(0, 0, 0, 0);
                    }
                    if (d < 190f)
                    {
                        float t = (d - 172f) / 18f;
                        return new Color32(0, 0, 0, (byte)Mathf.RoundToInt(t * 235f));
                    }
                    return new Color32(0, 0, 0, 235);
                });
            return SpriteOf(scopeTex);
        }

        static Texture2D pauseTex;
        public static Sprite PauseIcon()
        {
            if (pauseTex == null)
                pauseTex = MakeTex(64, 64, (x, y) =>
                {
                    bool bar = (x >= 18 && x <= 26 || x >= 38 && x <= 46) && y >= 10 && y <= 53;
                    return bar ? new Color32(255, 255, 255, 255) : new Color32(0, 0, 0, 0);
                });
            return SpriteOf(pauseTex);
        }

        static Texture2D flashTexture;
        public static Texture2D FlashTex()
        {
            if (flashTexture == null)
                flashTexture = MakeTex(64, 64, (x, y) =>
                {
                    float d = Vector2.Distance(new Vector2(x, y), new Vector2(31.5f, 31.5f)) / 32f;
                    float a = Mathf.Pow(Mathf.Clamp01(1f - d), 1.4f);
                    var c = Color.Lerp(new Color(1f, 1f, 0.75f), new Color(1f, 0.55f, 0.1f), d);
                    return new Color(c.r, c.g, c.b, a);
                });
            return flashTexture;
        }

        public static Sprite SpriteOf(Texture2D t)
        {
            return Sprite.Create(t, new Rect(0f, 0f, t.width, t.height), new Vector2(0.5f, 0.5f), 100f);
        }

        public static void Stretch(RectTransform rt)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }

        public static void Anchor(RectTransform rt, Vector2 aMin, Vector2 aMax, Vector2 oMin, Vector2 oMax)
        {
            rt.anchorMin = aMin;
            rt.anchorMax = aMax;
            rt.offsetMin = oMin;
            rt.offsetMax = oMax;
        }

        public static void AnchorPoint(RectTransform rt, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            rt.anchorMin = anchor;
            rt.anchorMax = anchor;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
        }

        public static Text MakeText(Transform parent, string name, string content, int size, Color color, TextAnchor align)
        {
            var go = new GameObject(name, typeof(Text));
            go.transform.SetParent(parent, false);
            var t = go.GetComponent<Text>();
            t.font = ResolveFont();
            t.fontSize = size;
            t.color = color;
            t.alignment = align;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            t.text = content;
            return t;
        }

        public static Image MakeImage(Transform parent, string name, Sprite sprite, Color color, bool raycast = false)
        {
            var go = new GameObject(name, typeof(Image));
            go.transform.SetParent(parent, false);
            var img = go.GetComponent<Image>();
            img.sprite = sprite;
            img.color = color;
            img.raycastTarget = raycast;
            return img;
        }

        public static Button MakeButton(Transform parent, string name, Sprite sprite, Color color, Action onClick)
        {
            var go = new GameObject(name, typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            var img = go.GetComponent<Image>();
            img.sprite = sprite;
            img.color = color;
            img.raycastTarget = true;
            var btn = go.GetComponent<Button>();
            btn.targetGraphic = img;
            btn.onClick.AddListener(() => onClick());
            return btn;
        }
    }
}
