using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace StrikeOps
{
    public sealed class FxSystem : MonoBehaviour
    {
        struct TracerFx { public LineRenderer Line; public float Life; }

        class QuadFx
        {
            public MeshRenderer Rend;
            public Material Mat;
            public Color BaseColor;
            public float Life;
            public float MaxLife;
        }

        readonly List<TracerFx> tracers = new List<TracerFx>();
        readonly List<QuadFx> impacts = new List<QuadFx>();
        readonly List<QuadFx> flashes = new List<QuadFx>();
        readonly List<QuadFx> bloods = new List<QuadFx>();

        Texture2D decalTex, flashTex, bloodTex;
        Material lineMat, flashMat, bloodMat;

        void Awake()
        {
            BuildTextures();
            BuildPools();
        }

        void BuildTextures()
        {
            decalTex = UiUtil.MakeTex(32, 32, (x, y) =>
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(15.5f, 15.5f)) / 16f;
                float a = Mathf.Clamp01(1f - d * 1.3f);
                return new Color(0.07f, 0.07f, 0.07f, a * a * 0.9f);
            });
            flashTex = UiUtil.FlashTex();
            bloodTex = UiUtil.MakeTex(32, 32, (x, y) =>
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(15.5f, 15.5f)) / 16f;
                float a = Mathf.Clamp01(1f - d * 1.1f);
                return new Color(0.55f, 0.06f, 0.06f, a * a * 0.85f);
            });
            lineMat = new Material(Shader.Find("Sprites/Default"));
            flashMat = new Material(Shader.Find("Sprites/Default")) { mainTexture = flashTex };
            bloodMat = new Material(Shader.Find("Sprites/Default")) { mainTexture = bloodTex };
        }

        void BuildPools()
        {
            for (int i = 0; i < 24; i++)
                tracers.Add(new TracerFx { Line = MakeLine(), Life = 0f });
            for (int i = 0; i < 24; i++)
                impacts.Add(MakeQuad(decalTex, new Color(1f, 1f, 1f, 0.9f), 2.2f));
            for (int i = 0; i < 16; i++)
                flashes.Add(MakeQuad(flashTex, Color.white, 0.09f));
            for (int i = 0; i < 16; i++)
                bloods.Add(MakeQuad(bloodTex, Color.white, 0.15f));
        }

        LineRenderer MakeLine()
        {
            var go = new GameObject("tracer");
            go.transform.SetParent(transform, false);
            var lr = go.AddComponent<LineRenderer>();
            lr.positionCount = 2;
            lr.startWidth = 0.03f;
            lr.endWidth = 0.008f;
            lr.material = lineMat;
            lr.startColor = new Color(1f, 0.85f, 0.4f, 0.9f);
            lr.endColor = new Color(1f, 0.6f, 0.2f, 0.1f);
            lr.shadowCastingMode = ShadowCastingMode.Off;
            lr.enabled = false;
            return lr;
        }

        QuadFx MakeQuad(Texture2D tex, Color color, float maxLife)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Quad);
            Destroy(go.GetComponent<Collider>());
            go.name = "fx";
            go.transform.SetParent(transform, false);
            var mr = go.GetComponent<MeshRenderer>();
            var mat = new Material(Shader.Find("Sprites/Default")) { mainTexture = tex };
            mr.sharedMaterial = mat;
            mr.shadowCastingMode = ShadowCastingMode.Off;
            go.SetActive(false);
            return new QuadFx { Rend = mr, Mat = mat, BaseColor = color, Life = 0f, MaxLife = maxLife };
        }

        public void SpawnTracer(Vector3 a, Vector3 b)
        {
            for (int i = 0; i < tracers.Count; i++)
            {
                if (tracers[i].Life > 0f) continue;
                var t = tracers[i];
                t.Line.SetPosition(0, a);
                t.Line.SetPosition(1, b);
                t.Line.enabled = true;
                t.Life = 0.05f;
                tracers[i] = t;
                return;
            }
        }

        public void SpawnImpact(Vector3 point, Vector3 normal, bool flesh)
        {
            if (flesh)
            {
                ActivateQuad(bloods, point + normal * 0.06f, Random.rotation, 0.35f);
            }
            else
            {
                var rot = Quaternion.LookRotation(normal) * Quaternion.Euler(0f, 0f, Random.Range(0f, 360f));
                ActivateQuad(impacts, point + normal * 0.015f, rot, 0.16f);
                ActivateQuad(flashes, point + normal * 0.08f, rot, 0.12f);
            }
        }

        void ActivateQuad(List<QuadFx> pool, Vector3 pos, Quaternion rot, float scale)
        {
            for (int i = 0; i < pool.Count; i++)
            {
                if (pool[i].Life > 0f) continue;
                var q = pool[i];
                q.Rend.transform.position = pos;
                q.Rend.transform.rotation = rot;
                q.Rend.transform.localScale = new Vector3(scale, scale, scale);
                q.Mat.color = q.BaseColor;
                q.Rend.gameObject.SetActive(true);
                q.Life = q.MaxLife;
                return;
            }
        }

        void Update()
        {
            for (int i = 0; i < tracers.Count; i++)
            {
                var t = tracers[i];
                if (t.Life <= 0f) continue;
                t.Life -= Time.deltaTime;
                if (t.Life <= 0f) t.Line.enabled = false;
                tracers[i] = t;
            }

            FadeList(impacts);
            FadeList(flashes);
            FadeList(bloods);
        }

        void FadeList(List<QuadFx> pool)
        {
            for (int i = 0; i < pool.Count; i++)
            {
                var q = pool[i];
                if (q.Life <= 0f) continue;
                q.Life -= Time.deltaTime;
                if (q.Life <= 0f)
                {
                    q.Rend.gameObject.SetActive(false);
                    continue;
                }
                float a = Mathf.Clamp01(q.Life / q.MaxLife);
                var c = q.BaseColor;
                c.a = c.a * a;
                q.Mat.color = c;
            }
        }
    }
}
