using System.Collections.Generic;
using UnityEngine;

namespace StrikeOps
{
    public enum Sfx { Shot, SmgShot, SniperShot, Hit, Kill, Reload, Empty, Switch }

    public static class SoundFactory
    {
        const int Rate = 22050;

        static bool built;
        static readonly Dictionary<Sfx, AudioClip> clips = new Dictionary<Sfx, AudioClip>();

        public static void Play(AudioSource src, Sfx sfx, float volume = 1f)
        {
            if (src == null) return;
            if (!built) Build();
            if (clips.TryGetValue(sfx, out var clip) && clip != null)
                src.PlayOneShot(clip, volume);
        }

        static void Build()
        {
            built = true;
            clips[Sfx.Shot] = BuildShot(0.16f, 34f, 130f);
            clips[Sfx.SmgShot] = BuildShot(0.11f, 46f, 170f);
            clips[Sfx.SniperShot] = BuildShot(0.34f, 14f, 80f);
            clips[Sfx.Hit] = BuildTone(0.05f, 1400f, 60f, 0.4f);
            clips[Sfx.Kill] = BuildKill();
            clips[Sfx.Reload] = BuildClick(0.07f);
            clips[Sfx.Empty] = BuildClick(0.04f);
            clips[Sfx.Switch] = BuildClick(0.05f);
        }

        static AudioClip BuildShot(float dur, float decay, float thumpHz)
        {
            int n = Mathf.CeilToInt(dur * Rate);
            var data = new float[n];
            var rng = new System.Random(1234);
            for (int i = 0; i < n; i++)
            {
                float t = (float)i / Rate;
                float env = Mathf.Exp(-t * decay);
                float noise = (float)(rng.NextDouble() * 2.0 - 1.0);
                float thump = Mathf.Sin(2f * Mathf.PI * thumpHz * t * Mathf.Exp(-t * 8f)) * 0.7f;
                data[i] = Mathf.Clamp(noise * env * 0.8f + thump * env, -1f, 1f) * 0.9f;
            }
            return Finalize("shot", data);
        }

        static AudioClip BuildTone(float dur, float hz, float decay, float vol)
        {
            int n = Mathf.CeilToInt(dur * Rate);
            var d = new float[n];
            for (int i = 0; i < n; i++)
            {
                float t = (float)i / Rate;
                d[i] = Mathf.Sin(2f * Mathf.PI * hz * t) * Mathf.Exp(-t * decay) * vol;
            }
            return Finalize("tone", d);
        }

        static AudioClip BuildKill()
        {
            float dur = 0.22f;
            int n = Mathf.CeilToInt(dur * Rate);
            var d = new float[n];
            for (int i = 0; i < n; i++)
            {
                float t = (float)i / Rate;
                float hz = t < 0.09f ? 880f : 1318f;
                d[i] = Mathf.Sin(2f * Mathf.PI * hz * t) * Mathf.Exp(-t * 18f) * 0.5f;
            }
            return Finalize("kill", d);
        }

        static AudioClip BuildClick(float dur)
        {
            int n = Mathf.CeilToInt(dur * Rate);
            var d = new float[n];
            var rng = new System.Random(77);
            for (int i = 0; i < n; i++)
            {
                float t = (float)i / Rate;
                d[i] = (float)(rng.NextDouble() * 2.0 - 1.0) * Mathf.Exp(-t * 220f) * 0.6f;
            }
            return Finalize("click", d);
        }

        static AudioClip Finalize(string name, float[] data)
        {
            var clip = AudioClip.Create(name, data.Length, 1, Rate, false);
            clip.SetData(data, 0);
            return clip;
        }
    }
}
